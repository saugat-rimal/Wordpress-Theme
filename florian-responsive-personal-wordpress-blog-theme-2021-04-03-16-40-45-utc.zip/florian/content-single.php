<?php
/**
 * @package Florian
 */

$post_classes = get_post_class();

$current_post_format = $post_classes[4];

$post_formats_media = array('format-audio', 'format-video', 'format-gallery');

// Post settings
$post_sidebarposition = get_post_meta( get_the_ID(), '_florian_post_sidebar_position', true );
$post_social_disable = get_post_meta( get_the_ID(), '_florian_post_social_disable', true );
$post_image_disable = get_post_meta( get_the_ID(), '_florian_post_image_disable', true );

// Post sidebar position
if(!isset($post_sidebarposition)||($post_sidebarposition == '')) {
	$post_sidebarposition = 0;
}

if($post_sidebarposition == "0") {
	$post_sidebarposition = get_theme_mod('sidebar_post', 'disable');
}

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['sidebar_post']) ) {
  $post_sidebarposition = $_GET['sidebar_post'];
}

if(is_active_sidebar( 'post-sidebar' ) && ($post_sidebarposition !== 'disable') ) {
	$span_class = 'col-md-9';

	florian_set_content_width(847);
}
else {
	$span_class = 'col-md-12 post-single-content';

	if(get_theme_mod('blog_post_smallwidth', false)) {
		florian_set_content_width(850);
	}
}

// Post media
$post_embed_video = get_post_meta( get_the_ID(), '_florian_video_embed', true );

if($post_embed_video !== '') {

	$post_embed_video_output = wp_oembed_get($post_embed_video);
} else {
	$post_embed_video_output = '';
}

$post_embed_audio = get_post_meta( get_the_ID(), '_florian_audio_embed', true );

if($post_embed_audio !== '') {

	$post_embed_audio_output = wp_oembed_get($post_embed_audio);

} else {
	$post_embed_audio_output = '';
}

// Gallery post type
$post_embed_gallery_output = '';

if($current_post_format == 'format-gallery') {

	$gallery_images_data = florian_cmb2_get_images_src( get_the_ID(), '_florian_gallery_file_list', 'florian-blog-thumb' );

	if(sizeof($gallery_images_data) > 0) {

		$post_gallery_id = 'blog-post-gallery-'.get_the_ID();
		$post_embed_gallery_output = '<div class="blog-post-gallery-wrapper owl-carousel" id="'.esc_attr($post_gallery_id).'" style="display: none;">';

		foreach ($gallery_images_data as $gallery_image) {
			$post_embed_gallery_output .= '<div class="blog-post-gallery-image"><a href="'.esc_url($gallery_image).'" rel="lightbox" title="'.the_title_attribute(array('echo' => false)).'"><img src="'.esc_url($gallery_image).'" alt="'.the_title_attribute(array('echo' => false)).'"/></a></div>';
		}

		$post_embed_gallery_output .= '</div>';

		wp_add_inline_script( 'florian-script', '(function($){
	            $(document).ready(function() {

	            	"use strict";

	                $("#'.$post_gallery_id.'").owlCarousel({
	                    items: 1,
	                    autoplay: true,
	                    autowidth: false,
	                    autoplayTimeout:2000,
	                    autoplaySpeed: 1000,
	                    navSpeed: 1000,
	                    nav: true,
	                    dots: false,
	                    loop: true,
	                    navText: false,
	                    responsive: {
	                        1199:{
	                            items:1
	                        },
	                        979:{
	                            items:1
	                        },
	                        768:{
	                            items:1
	                        },
	                        479:{
	                            items:1
	                        },
	                        0:{
	                            items:1
	                        }
	                    }
	                });

	            });})(jQuery);');

	}
}

// Header image
$header_background_image = get_post_meta( get_the_ID(), '_florian_header_image', true );

if(isset($header_background_image) && ($header_background_image!== '')) {
	$header_background_image_style = 'background-image: url('.$header_background_image.');';
	$header_background_class = ' with-bg';

} else {
	$header_background_image_style = '';
	$header_background_class = '';
}

?>

<div class="content-block">
<div class="container-fluid container-page-item-title<?php echo esc_attr($header_background_class); ?>" data-style="<?php echo esc_attr($header_background_image_style); ?>">
	<div class="row">
	<div class="col-md-12">
	<div class="page-item-title-single">
		<?php
		$categories_list = get_the_category_list(  ', '  );
		if ( $categories_list ) :
		?>
	    <div class="post-categories"><?php printf( '%1$s', $categories_list ); ?></div>
	    <?php endif; // End if categories ?>

	    <h1><?php the_title(); ?></h1>
	    <div class="post-subtitle-container">
	    <?php if(get_theme_mod('blog_posts_author', false) == true): ?>
	    <div class="post-date"><?php the_time(get_option( 'date_format' )); ?></div><div class="post-author"><?php the_author_posts_link();?></div><?php endif; // End if post author ?>
		</div>

	    <?php if(get_theme_mod('blog_post_info_header', false) == true): ?>
	    <div class="post-info clearfix">
			<?php if(!isset($post_social_disable) || !$post_social_disable): ?>
			<div class="post-info-share">
				<?php do_action('florian_social_share'); // this action called from plugin ?>
			</div>
			<?php endif; ?>
		</div>
		<?php endif; ?>
	</div>
	</div>
	</div>
</div>
<div class="post-container container <?php echo esc_attr('span-'.$span_class); ?>">
	<div class="row">
<?php if ( is_active_sidebar( 'post-sidebar' ) && ( $post_sidebarposition == 'left')) : ?>
		<div class="col-md-3 post-sidebar sidebar">
		<ul id="post-sidebar">
		  <?php dynamic_sidebar( 'post-sidebar' ); ?>
		</ul>
		</div>
		<?php endif; ?>
		<div class="<?php echo esc_attr($span_class); ?>">
			<div class="blog-post blog-post-single clearfix">
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="post-content-wrapper">

						<div class="post-content">
							<?php
							if ( has_post_thumbnail()&&!in_array($current_post_format, $post_formats_media)&&(!$post_image_disable ) && (get_theme_mod('blog_post_featured_image', true) == true )): // check if the post has a Post Thumbnail assigned to it.
							?>
							<div class="blog-post-thumb">

								<?php the_post_thumbnail('florian-blog-thumb'); ?>

							</div>
							<?php endif; ?>
							<?php

							if(in_array($current_post_format, $post_formats_media)) {
								echo '<div class="blog-post-thumb blog-post-thumb-media">';

							// Post media
							if($current_post_format == 'format-video') {
								echo '<div class="blog-post-media blog-post-media-video">';
								echo florian_wp_kses_data($post_embed_video_output);// escaping does not needed here, WordPress OEMBED function used for this var
								echo '</div>';
							}
							elseif($current_post_format == 'format-audio') {
								echo '<div class="blog-post-media blog-post-media-audio">';
								echo florian_wp_kses_data($post_embed_audio_output);// escaping does not needed here, WordPress OEMBED function used for this var
								echo '</div>';
							}
							elseif($current_post_format == 'format-gallery') {
								echo '<div class="blog-post-media blog-post-media-gallery">';
								echo wp_kses_post($post_embed_gallery_output);
								echo '</div>';
							}
								echo '</div>';
							}
							?>
							<?php
							// Single Blog Post page Top banner
							florian_banner_show('single_post_top');
							?>
							<?php if ( is_search() ) : // Only display Excerpts for Search ?>
							<div class="entry-summary">
								<?php the_excerpt(); ?>
							</div><!-- .entry-summary -->
							<?php else : ?>
							<div class="entry-content">
								<?php the_content('<div class="more-link">'.esc_html__( 'View more', 'florian' ).'</div>' ); ?>
								<?php
									wp_link_pages( array(
										'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'florian' ),
										'after'  => '</div>',
									) );
								?>
							</div><!-- .entry-content -->

							<?php
							// Single Blog Post page Bottom banner
							florian_banner_show('single_post_bottom');
							?>


							<?php if(get_theme_mod('blog_post_tags', true) == true): ?>
							<?php
								/* translators: used between list items, there is a space after the comma */
								$tags_list = get_the_tag_list( '', ' ' );
								if ( $tags_list ) :
							?>
							<div class="tags clearfix">
								<?php echo wp_kses_post($tags_list); ?>
							</div>
							<?php endif; // End if $tags_list ?>
							<?php endif; ?>


							<?php endif; ?>
							</div>

					</div>
				</article>

				<?php if(get_theme_mod('blog_post_info_bottom', true) == true): ?>
				<div class="post-info clearfix">

					<?php if(get_theme_mod('blog_post_comments', true) == true): ?>
					<?php if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) : ?>
					<div class="post-info-comments"><i class="fa fa-comment-o" aria-hidden="true"></i>
<a href="<?php echo esc_url(get_comments_link( $post->ID )); ?>"><?php echo esc_html(get_comments_number_text( esc_html__('Leave a comment', 'florian'), esc_html__('Comments: 1', 'florian'), esc_html__('Comments: %', 'florian') )); ?></a></div>
					<?php endif; ?>
					<?php endif; ?>

					<?php if(get_theme_mod('blog_post_views', true) == true): ?>
					<div class="post-info-views"><i class="fa fa-eye" aria-hidden="true"></i><?php echo esc_html__('Views: ', 'florian'); ?> <?php do_action('florian_post_views'); // this action called from plugin ?></div>
					<?php endif; ?>

					<?php if(get_theme_mod('blog_post_share', true) == true): ?>
					<?php if(!isset($post_social_disable) || !$post_social_disable): ?>
					<div class="post-info-share">
						<?php do_action('florian_social_share'); // this action called from plugin ?>
					</div>
					<?php endif; ?>
					<?php endif; ?>

				</div>
				<?php endif; ?>
			</div>

			<div class="blog-post-single-separator"></div>

			<?php if(get_theme_mod('blog_post_author', true) == true): ?>
				<?php if ( is_single() && get_the_author_meta( 'description' ) ) : ?>
					<?php get_template_part( 'author-bio' ); ?>
				<?php endif; ?>
			<?php endif; ?>

			<?php
			if(get_theme_mod('blog_post_nav', true) == true) {
				florian_content_nav( 'nav-below' );
			}
			?>

			<?php if(get_theme_mod('blog_post_related', false) == true): ?>
			<?php get_template_part( 'related-posts-loop' ); ?>
			<?php endif; ?>

			<?php if(get_theme_mod('blog_post_subscribe', false) == true): ?>
			<?php florian_subscribe_block_show(); ?>
			<?php endif; ?>

			<?php
				// If comments are open or we have at least one comment, load up the comment template
				if ( comments_open() || '0' != get_comments_number() )

					comments_template();
			?>

		</div>
		<?php if ( is_active_sidebar( 'post-sidebar' ) && ( $post_sidebarposition == 'right')) : ?>
		<div class="col-md-3 post-sidebar sidebar">
		<ul id="post-sidebar">
		  <?php dynamic_sidebar( 'post-sidebar' ); ?>
		</ul>
		</div>
		<?php endif; ?>
	</div>
	</div>
</div>
<?php
// Worth reading posts
if(get_theme_mod('blog_post_worthreading', false)) {
	// Get worth reading posts
	$post_worthreading_posts = get_post_meta( get_the_ID(), '_florian_worthreading_posts', true );
	$post_worthreading_post_count = sizeof($post_worthreading_posts);

	if($post_worthreading_posts !== '') {

		$post_worthreading_post_arr_id = rand(0, $post_worthreading_post_count-1);

		$post_worthreading_post_id = $post_worthreading_posts[$post_worthreading_post_arr_id];

		$post_image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_worthreading_post_id ), 'florian-blog-thumb-2column-sidebar');

		if(has_post_thumbnail( $post_worthreading_post_id )) {
	        $image_bg ='background-image: url('.$post_image[0].');';
	        $post_image_html ='<div class="post-worthreading-post-image"><a href="'.esc_url(get_permalink($post_worthreading_post_id)).'" class="hover-effect-img" data-style="'.esc_attr($image_bg).'"></a></div>';
	    }
	    else {
	        $image_bg = '';
	        $post_image_html ='';
	    }

		echo '<div class="post-worthreading-post-wrapper">';
		echo '<div class="post-worthreading-post-button"><a href="'.esc_url(get_permalink($post_worthreading_post_id)).'">'.esc_html__('Worth reading »', 'florian').'</a></div>';
		echo '<div class="post-worthreading-post-container">';
		echo '<div class="post-worthreading-post">';
		echo florian_wp_kses_data($post_image_html); // All dynamic content in this variable already escaped on line 333
		echo '<div class="post-worthreading-post-title"><a href="'.esc_url(get_permalink($post_worthreading_post_id)).'">'.esc_html(the_title_attribute(array('echo'=>false, 'post' => $post_worthreading_post_id))).'</a></div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}

}
?>
