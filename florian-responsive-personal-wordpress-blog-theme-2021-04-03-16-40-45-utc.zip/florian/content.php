<?php
/**
 * @package Florian
 */

$post_loop_details = florian_get_post_details();
$post_loop_id = $post_loop_details['post_loop_id'];
$span_class = $post_loop_details['span_class'];

$post_classes = get_post_class();

$current_post_format = $post_classes[4];

$post_formats_media = array('format-audio', 'format-video', 'format-gallery');
$post_formats_hidereadmore = array('format-quote', 'format-link', 'format-status');

$post_socialshare_disable = get_post_meta( get_the_ID(), '_post_socialshare_disable_value', true );

// Blog layout
# Default
$blog_layout = get_theme_mod('blog_layout', 'layout_default');

if ( defined('DEMO_MODE') && isset($_GET['blog_layout']) ) {
    $blog_layout = $_GET['blog_layout'];
}

# Text Layout
if($blog_layout == 'layout_text') {
	$blog_enable_layout_text = true;
} else {
	$blog_enable_layout_text = false;
}

# Advanced list
if($blog_layout == 'layout_list_advanced') {
	$blog_enable_advanced_list_post_design = true;
	$blog_layout = 'layout_list';
} else {
	$blog_enable_advanced_list_post_design = false;
}

# Advanced 2 columns
if($blog_layout == 'layout_2column_design_advanced') {
	$blog_enable_advanced_2column_design = true;
	$blog_layout = 'layout_2column_design';
} else {
	$blog_enable_advanced_2column_design = false;
}

# 2 columns
if($blog_layout == 'layout_2column_design') {
	$blog_enable_2column_design = true;
} else {
	$blog_enable_2column_design = false;
}

# Masonry
if($blog_layout == 'layout_masonry') {
	$blog_enable_masonry_design = true;
} else {
	$blog_enable_masonry_design = false;
}

/* Posts loops position for advanced layouts */
if(!isset($post_loop_id)) {
	$post_loop_id = 1;
}

if(($post_loop_id == 1)&&$blog_enable_advanced_2column_design) {
	$current_post_2column_advanced = true;
} else {
	$current_post_2column_advanced = false;
}

$current_post_advanced_list = false;

if(($post_loop_id == 1)&&$blog_enable_advanced_list_post_design) {
	$current_post_advanced_list = true;
} else {
	$current_post_advanced_list = false;
}

if($blog_layout == 'layout_list') {
	$current_post_list = true;
} else {
	$current_post_list = false;
}

if(is_sticky(get_the_ID())) {
	$current_post_sticky = true;
	$sticky_post_class = 'sticky';
} else {
	$current_post_sticky = false;
	$sticky_post_class = '';
}

$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'florian-blog-thumb');

if(has_post_thumbnail( get_the_ID() )) {
    $image_bg ='background-image: url('.$image[0].');';
}
else {
    $image_bg = '';
}

// Post Format options
$post_embed_video = get_post_meta( get_the_ID(), '_florian_video_embed', true );

if($post_embed_video !== '') {
	$post_embed_video_output = wp_oembed_get($post_embed_video);

} else {
	$post_embed_video_output = '';
}

$post_embed_audio = get_post_meta( get_the_ID(), '_florian_audio_embed', true );

if($post_embed_audio !== '') {
	$post_embed_audio_output = wp_oembed_get($post_embed_audio);

} else {
	$post_embed_audio_output = '';
}

// Gallery post type
$post_embed_gallery_output = '';

if($current_post_format == 'format-gallery') {

	// Default layout
	$blog_thumb_size = 'florian-blog-thumb';

	// 2 column layout
	if($blog_enable_2column_design && $span_class == 'col-md-12') {
		$blog_thumb_size = 'florian-blog-thumb-2column';
	}

	if($blog_enable_2column_design && $span_class == 'col-md-9') {
		$blog_thumb_size = 'florian-blog-thumb-2column-sidebar';
	}

	// Advanced 2 column layout
	if($blog_enable_2column_design && $current_post_2column_advanced && $span_class == 'col-md-12') {
		$blog_thumb_size = 'florian-blog-thumb';
	}

	if($blog_enable_2column_design && $current_post_2column_advanced && $span_class == 'col-md-9') {
		$blog_thumb_size = 'florian-blog-thumb-sidebar';
	}

	$gallery_images_data = florian_cmb2_get_images_src( get_the_ID(), '_florian_gallery_file_list', $blog_thumb_size );

	if(sizeof($gallery_images_data) > 0) {

		$post_gallery_id = 'blog-post-gallery-'.get_the_ID();
		$post_embed_gallery_output = '<div class="blog-post-gallery-wrapper owl-carousel" id="'.$post_gallery_id.'" style="display: none;">';

		foreach ($gallery_images_data as $gallery_image) {
			$post_embed_gallery_output .= '<div class="blog-post-gallery-image"><a href="'.esc_url(get_the_permalink()).'"><img src="'.esc_attr($gallery_image).'" alt="'.the_title_attribute(array('echo' => false)).'"/></a></div>';
		}

		$post_embed_gallery_output .= '</div>';

	    wp_add_inline_script( 'florian-script', '(function($){
	            $(document).ready(function() {

	            	"use strict";

	                $("#'.$post_gallery_id.'").owlCarousel({
	                    items: 1,
	                    autoplay: true,
	                    autowidth: false,
	                    autoplayTimeout:2000,
	                    autoplaySpeed: 1000,
	                    navSpeed: 1000,
	                    nav: true,
	                    dots: false,
	                    loop: true,
	                    navText: false,
	                    responsive: {
	                        1199:{
	                            items:1
	                        },
	                        979:{
	                            items:1
	                        },
	                        768:{
	                            items:1
	                        },
	                        479:{
	                            items:1
	                        },
	                        0:{
	                            items:1
	                        }
	                    }
	                });

	            });})(jQuery);');

	}
}

// Post Loops Middle Banner
if(($post_loop_id - 1 == floor(get_option('posts_per_page')/2))&&(!$blog_enable_2column_design)&&(!$blog_enable_masonry_design)) {
	florian_banner_show('posts_loop_middle');
}

// Post header display layout (depends on blog layout)
// Post data above image
if($blog_layout == 'layout_default' || $current_post_2column_advanced || $current_post_advanced_list) {
	$post_header_display = 'above_image';
} else {
	$post_header_display = 'below_image';
}

// Read more button display default
$show_read_more = false;
?>
<?php if(!has_post_thumbnail( get_the_ID() )) { $sticky_post_class .= ' sticky-post-without-image'; } else { $sticky_post_class .= ''; } ?>
<div class="content-block blog-post clearfix<?php if($blog_enable_advanced_2column_design) { echo ' blog-post-advanced-2column';} if($current_post_advanced_list) { echo ' blog-post-advanced-list';} if($current_post_2column_advanced) { echo ' current-blog-post-advanced-2column';} if($blog_enable_layout_text) { echo ' blog-post-text-layout';} if($current_post_list) { echo ' blog-post-list-layout';} if($blog_enable_2column_design) { echo ' blog-post-2-column-layout';} if($blog_layout == 'layout_default') { echo ' blog-post-layout-default';}?>"<?php florian_add_aos(); ?>>
	<article id="post-<?php the_ID(); ?>" <?php post_class($sticky_post_class); ?>>

		<div class="post-content-wrapper"<?php if(($current_post_sticky)&&($blog_enable_masonry_design)&&($image_bg !== '')&&(!in_array($current_post_format, $post_formats_media))) { echo ' data-style="'.esc_attr($image_bg).'"'; } ?>>
			<?php if(($current_post_sticky)&&($blog_enable_masonry_design)): ?>
				<div class="sticky-post-badge<?php if($image_bg == '') { echo ' sticky-post-without-image'; } ?>"><i class="fa fa-star" aria-hidden="true"></i>
</div>
			<?php endif; ?>

			<?php
			// POST HEADER - post data above image
			if($post_header_display == 'above_image'):
			?>
			<div class="post-header-above-image">
			<?php

			$categories_list = get_the_category_list(  ', '  );
			if ( $categories_list ) :
			?>

			<div class="post-categories"><?php printf( esc_html__( '%1$s', 'florian' ), $categories_list ); ?></div>

			<?php endif; // End if categories ?>

			<h2 class="entry-title post-header-title lined"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?><?php if($current_post_sticky&&!$blog_enable_masonry_design) { echo '<sup><i class="fa fa-star" aria-hidden="true"></i>
</sup>'; } ?></a></h2>

			<div class="post-subtitle-container">
				<div class="post-info-date"><?php the_time(get_option( 'date_format' ));  ?></div><?php if(get_theme_mod('blog_posts_author', false) == true): ?><div class="post-author"><?php the_author_posts_link();?></div><?php endif; // End if post author ?>
			</div>

			</div>
			<?php endif; // End if layouts for post header above image ?>

			<?php
			// List post thumb
			if(($current_post_list)&&!$blog_enable_masonry_design&&!$blog_enable_layout_text):
			?>
				<?php if($current_post_advanced_list &&(!in_array($current_post_format, $post_formats_media))):?>

				<div class="blog-post-thumb-list-advanced">
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="hover-effect-img">
					<?php the_post_thumbnail('florian-blog-thumb'); ?>
					</a>
				</div>
				<?php else: ?>
				<?php
	          	if(($image_bg !== '')&&(!in_array($current_post_format, $post_formats_media))):
				?>
				<div class="blog-post-thumb-wrapper">
					<a class="blog-post-thumb hover-effect-img" href="<?php the_permalink(); ?>" rel="bookmark" data-style="<?php echo esc_attr($image_bg); ?>"></a>
				</div>
				<?php endif;?>

				<?php endif;?>

				<?php
					if(in_array($current_post_format, $post_formats_media)) {

						if( ($post_embed_video_output !== '')||($post_embed_audio_output !== '')||($post_embed_gallery_output !== '') ) {

							echo '<div class="blog-post-thumb-wrapper blog-post-thumb-wrapper-media">';

							// Post media
							if($current_post_format == 'format-video') {
								echo '<div class="blog-post-media blog-post-media-video">';
								echo florian_wp_kses_data($post_embed_video_output);// escaping does not needed here, WordPress OEMBED function used for this var
								echo '</div>';
							}
							elseif($current_post_format == 'format-audio') {
								echo '<div class="blog-post-media blog-post-media-audio">';
								echo florian_wp_kses_data($post_embed_audio_output);// escaping does not needed here, WordPress OEMBED function used for this var
								echo '</div>';
							}
							elseif($current_post_format == 'format-gallery') {
								echo '<div class="blog-post-media blog-post-media-gallery clearfix">';
								echo wp_kses_post($post_embed_gallery_output);
								echo '</div>';


							}

							echo '</div>';

						}
					}

				?>
			<?php endif;?>

			<?php
			// Masonry thumbnail
			if($blog_enable_masonry_design) {

				if ( has_post_thumbnail() && (!$current_post_sticky)&&!in_array($current_post_format, $post_formats_media) ):
				?>

				<div class="blog-post-thumb">
					<a href="<?php the_permalink(); ?>" rel="bookmark" class="hover-effect-img">
					<?php the_post_thumbnail('florian-blog-thumb-masonry'); ?>
					</a>
				</div>
				<?php
				endif;

				// Masonry media posts
				if(in_array($current_post_format, $post_formats_media)) {

					if( ($post_embed_video_output !== '')||($post_embed_audio_output !== '')||($post_embed_gallery_output !== '') ) {

						echo '<div class="blog-post-thumb">';

						// Post media
						if($current_post_format == 'format-video') {
							echo '<div class="blog-post-media blog-post-media-video">';
							echo florian_wp_kses_data($post_embed_video_output);// escaping does not needed here, WordPress OEMBED function used for this var
							echo '</div>';
						}
						elseif($current_post_format == 'format-audio') {
							echo '<div class="blog-post-media blog-post-media-audio">';
							echo florian_wp_kses_data($post_embed_audio_output);// escaping does not needed here, WordPress OEMBED function used for this var
							echo '</div>';
						}
						elseif($current_post_format == 'format-gallery') {
							echo '<div class="blog-post-media blog-post-media-gallery clearfix">';
							echo wp_kses_post($post_embed_gallery_output);
							echo '</div>';


						}

						echo '</div>';

					}
				}
			}
			?>
			<?php
			// Regular post thumb
			if((!$current_post_list)&&(!$blog_enable_masonry_design)&&(!$blog_enable_layout_text)) {

				// Post media
				if(($current_post_format == 'format-video')&&($post_embed_video_output !== '')) {
					echo '<div class="blog-post-thumb blog-post-thumb-media">';
					echo '<div class="blog-post-media blog-post-media-video">';
					echo florian_wp_kses_data($post_embed_video_output);// escaping does not needed here, WordPress OEMBED function used for this var
					echo '</div>';
					echo '</div>';
				}
				elseif(($current_post_format == 'format-audio')&&($post_embed_audio_output !== '')) {
					echo '<div class="blog-post-thumb">';
					echo '<div class="blog-post-media blog-post-media-audio">';
					echo florian_wp_kses_data($post_embed_audio_output);// escaping does not needed here, WordPress OEMBED function used for this var
					echo '</div>';
					echo '</div>';
				}
				elseif(($current_post_format == 'format-gallery')&&($post_embed_gallery_output !== '')) {
					echo '<div class="blog-post-thumb">';
					echo '<div class="blog-post-media blog-post-media-gallery clearfix">';
					echo wp_kses_post($post_embed_gallery_output);
					echo '</div>';
					echo '</div>';


				} else {
					// Post thumbnail sizes
					if ( has_post_thumbnail() ):

						// Default layout
						$blog_thumb_size = 'florian-blog-thumb';

						// 2 column layout
						if($blog_enable_2column_design && $span_class == 'col-md-12') {
							$blog_thumb_size = 'florian-blog-thumb-2column';
						}

						if($blog_enable_2column_design && $span_class == 'col-md-9') {
							$blog_thumb_size = 'florian-blog-thumb-2column-sidebar';
						}

						// Advanced 2 column layout
						if($blog_enable_2column_design && $current_post_2column_advanced && $span_class == 'col-md-12') {
							$blog_thumb_size = 'florian-blog-thumb';
						}

						if($blog_enable_2column_design && $current_post_2column_advanced && $span_class == 'col-md-9') {
							$blog_thumb_size = 'florian-blog-thumb-sidebar';
						}

					?>
						<div class="blog-post-thumb">
						<a href="<?php the_permalink(); ?>" rel="bookmark" class="hover-effect-img">
						<?php the_post_thumbnail($blog_thumb_size); ?>
						</a>
						</div>

					<?php
					endif;
				}


			}

			?>



			<div class="post-content">


				<?php
				// POST HEADER - post data below image
				if($post_header_display == 'below_image'):
				?>
				<div class="post-header-below-image">
				<?php
				$categories_list = get_the_category_list(  ', '  );
				if ( $categories_list ) :
				?>

				<div class="post-categories"><?php printf( esc_html__( '%1$s', 'florian' ), $categories_list ); ?></div>

				<?php endif; // End if categories ?>

				<h2 class="entry-title post-header-title lined"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?><?php if($current_post_sticky&&!$blog_enable_masonry_design) { echo '<sup><i class="fa fa-star" aria-hidden="true"></i>
	</sup>'; } ?></a></h2>
				<?php if(get_theme_mod('blog_posts_author', false) == true): ?>
				<div class="post-subtitle-container">
					<div class="post-info-date"><?php the_time(get_option( 'date_format' ));  ?></div><?php if(get_theme_mod('blog_posts_author', false) == true): ?><div class="post-author"><?php the_author_posts_link();?></div><?php endif; // End if post author ?>
				</div>
				<?php endif; // End if post author ?>
				</div>
				<?php endif; // End if layouts for post data below image ?>

				<?php
				// Don't show short content if user disabled it
				if((get_theme_mod('blog_posts_excerpt', 'content') !== 'none') || $blog_enable_masonry_design):?>
				<div class="entry-content">
					<?php

					// Post content
					if($blog_enable_masonry_design) {
						if(in_array($current_post_format, $post_formats_hidereadmore)) {
							the_content('');

						} else {
							the_excerpt();
						}

						if(get_the_excerpt() !== get_the_content()) {
							?>
							<div class="post-info-readmore"><a href="<?php the_permalink(); ?>" class="more-link btn btn-bordered"><?php esc_html_e('View more', 'florian'); ?></a></div>
							<?php
						}
						?>
						<?php

					} else {
						// Post loop type excerpt
						if(get_theme_mod('blog_posts_excerpt', 'content') == 'excerpt') {
							if(in_array($current_post_format, $post_formats_hidereadmore)) {
								the_content('');
								$show_read_more = false;
							} else {
								the_excerpt();

								if(get_the_excerpt() !== get_the_content()) {
									$show_read_more = true;
								}

								?>

								<?php
							}
						}

						// Post loop type content
						if(get_theme_mod('blog_posts_excerpt', 'content') == 'content') {

							the_content('');
							if(get_the_excerpt() !== get_the_content()) {
								$show_read_more = true;
							}
							?>
							<?php
						}

						if($current_post_list && !$current_post_advanced_list && get_the_excerpt() !== get_the_content()) {
							?>
							<div class="post-info-readmore"><a href="<?php the_permalink(); ?>" class="more-link btn btn-bordered"><?php esc_html_e('View more', 'florian'); ?></a></div>
							<?php
						}


						wp_link_pages( array(
							'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'florian' ),
							'after'  => '</div>',
						) );
					}

					?>
				</div><!-- .entry-content -->
				<?php endif; ?>

			</div>
			<?php
			// Read more display for different layouts
			if($current_post_list) {
				$show_read_more = false;
			}

			if($current_post_advanced_list) {
				$show_read_more = true;
			}

			if($show_read_more && !$current_post_list || $blog_layout == 'layout_default' || $current_post_2column_advanced || $current_post_advanced_list):?>
			<div class="post-info clearfix">
				<?php if($show_read_more):?>
				<div class="post-info-readmore"><a href="<?php the_permalink(); ?>" class="more-link btn btn-bordered"><?php esc_html_e('View more', 'florian'); ?></a></div>
				<?php endif; ?>

				<?php if($blog_layout == 'layout_default' || $current_post_2column_advanced || $current_post_advanced_list): // show post-info on selected layouts ?>

				<?php if(get_theme_mod('blog_posts_comments', true) == true):?>
				<?php if ( ! post_password_required() && ( comments_open() || '0' != get_comments_number() ) ) : ?>
				<div class="post-info-comments"><i class="fa fa-comment-o" aria-hidden="true"></i><a href="<?php echo esc_url(get_comments_link( $post->ID )); ?>"><?php echo esc_html(get_comments_number_text( esc_html__('Leave a comment', 'florian'), esc_html__('1', 'florian'), esc_html__('%', 'florian') )); ?></a></div>
				<?php endif; ?>
				<?php endif; ?>

				<?php if(get_theme_mod('blog_posts_views', false) == true): ?>
				<div class="post-info-views"><i class="fa fa-eye" aria-hidden="true"></i><?php do_action('florian_post_views'); // this action called from plugin ?></div>
				<?php endif; ?>

				<?php if(get_theme_mod('blog_posts_share', true) == true): ?>
				<?php if(!isset($post_socialshare_disable) || !$post_socialshare_disable): ?>
				<div class="post-info-share">
					<?php do_action('florian_social_share'); // this action called from plugin ?>
				</div>
				<?php endif; ?>
				<?php endif; ?>

				<?php endif; // show post-info on selected layouts ?>
			</div>
			<?php endif; ?>
			<div class="clear"></div>

		</div>

	</article>
	<?php if(get_theme_mod('blog_posts_related', false) == true && !$blog_enable_masonry_design && !$blog_enable_layout_text && !$blog_enable_2column_design): ?>
		<?php get_template_part( 'related-posts-loop' ); ?>
	<?php endif; ?>
</div>

