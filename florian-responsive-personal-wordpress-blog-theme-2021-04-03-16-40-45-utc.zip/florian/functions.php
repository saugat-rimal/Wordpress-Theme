<?php
/**
 * Florian functions
 *
 * @package Florian
 */

/**
 * WordPress content width configuration
 */
if (!isset($content_width))
	$content_width = 1140; /* pixels */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
if(!function_exists('florian_setup')):
function florian_setup() {

	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 * If you're building a theme based on Florian, use a find and replace
	 * to change 'florian' to the name of your theme in all the template files
	 */
	load_theme_textdomain('florian', get_template_directory() . '/languages');

	/**
	 * Add default posts and comments RSS feed links to head
	 */
	add_theme_support('automatic-feed-links');

	/**
	 * Enable support for Post Thumbnails on posts and pages
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support('post-thumbnails');

  /**
   * Enable support Gutenberg features
   */
  add_theme_support( 'align-wide' );

	/**
	 * Enable support for JetPack Infinite Scroll
	 *
	 * @link https://jetpack.me/support/infinite-scroll/
	 */
	add_theme_support( 'infinite-scroll', array(
	    'container' => 'content',
	    'footer' => 'page',
	) );

	/**
	 * Enable support for Title Tag
	 *
	 */
	add_theme_support( 'title-tag' );

	/**
	 * Enable support for Logo
	 */
	add_theme_support( 'custom-header', array(
	    'default-image' =>  get_template_directory_uri() . '/img/logo.png',
            'width'         => 165,
            'flex-width'    => true,
            'flex-height'   => false,
            'header-text'   => false,
	));

	/**
	 *	Woocommerce support
	 */
	add_theme_support( 'woocommerce' );

	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	/**
	 * Enable support for Post Formats
	 */
	add_theme_support('post-formats', array('aside', 'image', 'gallery', 'video', 'audio', 'quote', 'link', 'status', 'chat'));

	/**
	 * Theme images sizes
	 */
	add_image_size( 'florian-blog-thumb', 1140, 694, true);
	add_image_size( 'florian-blog-thumb-sidebar', 848, 517, true);
	add_image_size( 'florian-blog-thumb-2column', 555, 407, true);
	add_image_size( 'florian-blog-thumb-2column-sidebar', 409, 300, true);
  add_image_size( 'florian-blog-thumb-masonry', 409, 300, false);
	add_image_size( 'florian-blog-thumb-widget', 90, 90, true);

	/**
	 * Theme menus locations
	 */
	register_nav_menus( array(
        'primary' => esc_html__('Header Menu', 'florian'),
        'top' => esc_html__('Top Menu', 'florian'),
        'footer' => esc_html__('Footer Menu', 'florian'),
	) );

  // Filters the oEmbed process to run the responsive_embed() function
  add_filter('embed_oembed_html', 'florian_responsive_embed', 10, 3);

  // Activate theme
  update_option('florian_license_key_status', 'activated');

}
endif;
add_action('after_setup_theme', 'florian_setup');

/*
* Change posts excerpt length
*/
if(!function_exists('florian_new_excerpt_length')):
function florian_new_excerpt_length($length) {
	$post_excerpt_length = get_theme_mod('blog_posts_excerpt_limit', 40);

	return $post_excerpt_length;
}
endif;
add_filter('excerpt_length', 'florian_new_excerpt_length');

/**
 * Enqueue scripts and styles
 */
if(!function_exists('florian_scripts')):
function florian_scripts() {

	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/css/bootstrap.css');
	wp_enqueue_style('owl-main', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.css');
	wp_enqueue_style('florian-stylesheet', get_stylesheet_uri(), array(), '1.0.2', 'all');
	wp_enqueue_style('florian-responsive', get_template_directory_uri() . '/responsive.css', '1.0.2', 'all');

	if ( true == get_theme_mod( 'animations_css3', true ) )  {
		wp_enqueue_style('florian-animations', get_template_directory_uri() . '/css/animations.css');
	}

	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.css');
	wp_enqueue_style('florian-select2', get_template_directory_uri() . '/js/select2/select2.css'); // special version, must be prefixed with theme prefix
	wp_enqueue_style('swiper', get_template_directory_uri() . '/css/idangerous.swiper.css');

  // Animation on scroll
  wp_enqueue_style('aos', get_template_directory_uri() . '/js/aos/aos.css');
  wp_register_script('aos', get_template_directory_uri() . '/js/aos/aos.js', array(), '2.3.1', true);
  wp_enqueue_script('aos');

	add_thickbox();

	// Registering scripts to include it in correct order later
	wp_register_script('bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '3.1.1', true);
	wp_register_script('easing', get_template_directory_uri() . '/js/easing.js', array(), '1.3', true);
	wp_register_script('florian-select2', get_template_directory_uri() . '/js/select2/select2.min.js', array(), '3.5.1', true);  // special version, must be prefixed with theme prefix
	wp_register_script('owl-carousel', get_template_directory_uri() . '/js/owl-carousel/owl.carousel.min.js', array(), '2.0.0', true);


	// Enqueue scripts in correct order
	wp_enqueue_script('florian-script', get_template_directory_uri() . '/js/template.js', array('jquery', 'bootstrap', 'easing', 'florian-select2', 'owl-carousel'), '1.0', true);

	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}

}
endif;
add_action('wp_enqueue_scripts', 'florian_scripts');

/**
 * Enqueue scripts and styles for admin area
 */
if(!function_exists('florian_admin_scripts')):
function florian_admin_scripts() {
	wp_register_style( 'florian-style-admin', get_template_directory_uri() .'/css/admin.css' );
	wp_enqueue_style( 'florian-style-admin' );
	wp_register_style('florian-font-awesome-admin', get_template_directory_uri() . '/css/font-awesome.css');
	wp_enqueue_style( 'florian-font-awesome-admin' );

	wp_register_script('florian-template-admin', get_template_directory_uri() . '/js/template-admin.js', array(), '1.0', true);
	wp_enqueue_script('florian-template-admin');
}
endif;
add_action( 'admin_init', 'florian_admin_scripts' );

if(!function_exists('florian_load_wp_media_files')):
function florian_load_wp_media_files() {
  wp_enqueue_media();
}
endif;
add_action( 'admin_enqueue_scripts', 'florian_load_wp_media_files' );

/**
 * Display navigation to next/previous pages when applicable
 */
if(!function_exists('florian_content_nav')):
function florian_content_nav( $nav_id ) {
  global $wp_query, $post;

  // Loading library to check active plugins
  include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

  // Don't print empty markup on single pages if there's nowhere to navigate.
  if ( is_single() ) {
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next = get_adjacent_post( false, '', false );

    if ( ! $next && ! $previous )
      return;
  }

  // Don't print empty markup in archives if there's only one page.
  if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) )
    return;

  $nav_class = ( is_single() ) ? 'navigation-post' : 'navigation-paging';

  ?>
  <nav id="<?php echo esc_attr( $nav_id ); ?>" class="<?php echo esc_attr($nav_class); ?>">

  <?php if ( is_single() ) : // navigation links for single posts ?>
  <div class="container-fluid">
  <div class="row">
    <div class="col-md-6 nav-post-prev">
    <?php
    $prev_post = get_previous_post();
    if ( is_a( $prev_post , 'WP_Post' ) ) { ?>
      <a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>"><div class="nav-post-title"><?php esc_html_e( 'Previous', 'florian' ); ?></div><div class="nav-post-name"><?php echo esc_html(the_title_attribute(array('echo'=>false, 'post' => $prev_post->ID))); ?></div></a>
    <?php }
    ?>
    </div>
    <div class="col-md-6 nav-post-next">
    <?php
    $next_post = get_next_post();
    if ( is_a( $next_post , 'WP_Post' ) ) { ?>
      <a href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>"><div class="nav-post-title"><?php esc_html_e( 'Next', 'florian' ); ?></div><div class="nav-post-name"><?php echo esc_html(the_title_attribute(array('echo'=>false, 'post' => $next_post->ID))); ?></div></a>
    <?php }
    ?>
    </div>

  </div>
  </div>
  <?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>
  <div class="clear"></div>
  <div class="container-fluid">
    <div class="row">
      <?php if ( function_exists( 'wp_pagenavi' ) ): ?>
        <div class="col-md-12 nav-pagenavi">
        <?php wp_pagenavi(); ?>
        </div>
      <?php else: ?>
        <div class="col-md-6 nav-post-prev">
        <?php if ( get_next_posts_link() ) : ?>
        <?php next_posts_link( esc_html__( 'Older posts', 'florian' ) ); ?>
        <?php endif; ?>
        </div>

        <div class="col-md-6 nav-post-next">
        <?php if ( get_previous_posts_link() ) : ?>
        <?php previous_posts_link( esc_html__( 'Newer posts', 'florian' ) ); ?>
        <?php endif; ?>
        </div>
      <?php endif; ?>

    </div>
  </div>
  <?php endif; ?>

  </nav>
  <?php
}
endif;

/**
 * Template for comments and pingbacks.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 */
if(!function_exists('florian_comment')):
function florian_comment( $comment, $args, $depth ) {
  $GLOBALS['comment'] = $comment;

  if ( 'pingback' == $comment->comment_type || 'trackback' == $comment->comment_type ) : ?>

  <li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
    <div class="comment-body">
      <?php esc_html_e( 'Pingback:', 'florian' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( 'Edit', 'florian' ), '<span class="edit-link">', '</span>' ); ?>
    </div>

  <?php else : ?>

  <li id="comment-<?php comment_ID(); ?>" <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?>>
    <article id="div-comment-<?php comment_ID(); ?>" class="comment-body">

      <div class="comment-meta clearfix">
        <div class="reply">
          <?php edit_comment_link( esc_html__( 'Edit', 'florian' ), '', '' ); ?>
          <?php comment_reply_link( array_merge( $args, array( 'add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
        </div><!-- .reply -->
        <div class="comment-author vcard">

          <?php if ( 0 != $args['avatar_size'] ) echo get_avatar( $comment, 100 ); ?>

        </div><!-- .comment-author -->

        <div class="comment-metadata">
          <div class="author">
          <?php printf('%s', sprintf( '<cite class="fn">%s</cite>', get_comment_author_link() ) ); ?>
          </div>
          <div class="date"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ); ?>"><time datetime="<?php comment_time( 'c' ); ?>"><?php printf( _x( '%1$s at %2$s', '1: date, 2: time', 'florian' ), get_comment_date(), get_comment_time() ); ?></time></a></div>

          <?php if ( '0' == $comment->comment_approved ) : ?>
          <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'florian' ); ?></p>
          <?php endif; ?>
          <div class="comment-content">
            <?php comment_text(); ?>
          </div>
        </div><!-- .comment-metadata -->

      </div><!-- .comment-meta -->

    </article><!-- .comment-body -->

  <?php
  endif;
}
endif;

// Set/Get current post details for global usage in templates (post position in loop, etc)
if(!function_exists('florian_set_post_details')):
function florian_set_post_details($details) {
	global $florian_post_details;

	$florian_post_details = $details;
}
endif;

if(!function_exists('florian_get_post_details')):
function florian_get_post_details() {
	global $florian_post_details;

	return $florian_post_details;
}
endif;

/**
 * Registers an editor stylesheet
 */
if(!function_exists('florian_add_editor_styles')):
function florian_add_editor_styles() {
    add_editor_style( 'custom-editor-style.css' );
}
add_action('admin_init', 'florian_add_editor_styles');
endif;

/**
 * Social services list
 */
if(!function_exists('florian_social_services_list')):
function florian_social_services_list() {
  // You can add more social services here, array keys must beequal to Font Awesome icons names, without 'fa-' prefix
  // Available icons list: https://fontawesome.com/v4.7.0/icons/
  $social_services_array = array(
      'facebook' => esc_attr__( 'Facebook', 'florian' ),
      'vk' => esc_attr__( 'VKontakte', 'florian' ),
      'google-plus' => esc_attr__( 'Google+', 'florian' ),
      'twitter' => esc_attr__( 'Twitter', 'florian' ),
      'linkedin' => esc_attr__( 'LinkedIn', 'florian' ),
      'dribbble' => esc_attr__( 'Dribbble', 'florian' ),
      'behance' => esc_attr__( 'Behance', 'florian' ),
      'instagram' => esc_attr__( 'Instagram', 'florian' ),
      'tumblr' => esc_attr__( 'Tumblr', 'florian' ),
      'pinterest' => esc_attr__( 'Pinterest', 'florian' ),
      'vimeo-square' => esc_attr__( 'Vimeo', 'florian' ),
      'youtube' => esc_attr__( 'Youtube', 'florian' ),
      'twitch' => esc_attr__( 'Twitch', 'florian' ),
      'skype' => esc_attr__( 'Skype', 'florian' ),
      'flickr' => esc_attr__( 'Flickr', 'florian' ),
      'deviantart' => esc_attr__( 'Deviantart', 'florian' ),
      '500px' => esc_attr__( '500px', 'florian' ),
      'etsy' => esc_attr__( 'Etsy', 'florian' ),
      'telegram' => esc_attr__( 'Telegram', 'florian' ),
      'odnoklassniki' => esc_attr__( 'Odnoklassniki', 'florian' ),
      'houzz' => esc_attr__( 'Houzz', 'florian' ),
      'slack' => esc_attr__( 'Slack', 'florian' ),
      'qq' => esc_attr__( 'QQ', 'florian' ),
      'github' => esc_attr__( 'Github', 'florian' ),
      'whatsapp' => esc_attr__( 'WhatsApp', 'florian' ),
      'telegram' => esc_attr__( 'Telegram', 'florian' ),
      'rss' => esc_attr__( 'RSS', 'florian' ),
      'envelope-o' => esc_attr__( 'Email', 'florian' ),
      'address-card-o' => esc_attr__( 'Other', 'florian' ),
  );

  return $social_services_array;
}
endif;

/**
 * Set content width
 */
if(!function_exists('florian_set_content_width')):
function florian_set_content_width($width) {
    global $content_width;// Global here used to define new content width for global WordPress system variable

    $content_width = $width;
}
endif;

/*
* Process already escaped complex data
*/
function florian_wp_kses_data($data) {
  // This function used in safe places only, where all dynamic data already escaped before,
  // and does not need double escaping

  return $data;
}

/**
 * Adds a responsive embed wrapper around oEmbed content
 */
function florian_responsive_embed($html, $url, $attr) {
    return $html!=='' ? '<div class="embed-container">'.$html.'</div>' : '';
}

/**
 * Load theme options.
 */
require get_template_directory() . '/inc/theme-options.php';

/**
 * Load theme functions.
 */
require get_template_directory() . '/inc/theme-functions.php';

/**
 * Load theme sidebars.
 */
require get_template_directory() . '/inc/theme-sidebars.php';

/**
 * Load theme dynamic CSS.
 */
require get_template_directory() . '/inc/theme-css.php';

/**
 * Load theme dynamic JS.
 */
require get_template_directory() . '/inc/theme-js.php';

/**
 * Theme dashboard.
 */
require get_template_directory() . '/inc/theme-dashboard/class-theme-dashboard.php';

/**
 * Load additional theme modules.
 */
# Module - Category image
require get_template_directory() . '/inc/modules/category-image/category-image.php';

# Module - Mega Menu
if(get_theme_mod('module_mega_menu', true)) {
  require get_template_directory() . '/inc/modules/mega-menu/custom-menu.php';
}
