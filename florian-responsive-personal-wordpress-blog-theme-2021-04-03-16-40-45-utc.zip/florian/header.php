<?php
/**
 * WP Theme Header
 *
 * Displays all of the <head> section
 *
 * @package Florian
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<?php florian_top_show(); ?>

<?php
// Site Header Banner
florian_banner_show('below_homepage_popular_posts');
?>

<?php
// Popular posts
$show_popular_posts = true;

if(get_theme_mod('popularposts_homepage', true) && is_front_page()) {
  $show_popular_posts = true;
}
if(get_theme_mod('popularposts_homepage', true) && !is_front_page()) {
  $show_popular_posts = false;
}

if($show_popular_posts) {
  florian_popularposts_slider_show();
}
?>

<?php
// Logo position
$header_container_add_class = ' header-logo-'.esc_attr(get_theme_mod('logo_position', 'center'));

?>
<?php
// Disable header
if(get_theme_mod('header_disable', false) == false):
?>
<?php
// Header Banner
florian_banner_show('header');
?>
<header class="clearfix">
<div class="container<?php echo esc_attr($header_container_add_class); ?>">
  <div class="row">
    <div class="col-md-12">

      <div class="header-left">
        <?php florian_header_left_show(); ?>
      </div>

      <div class="header-center">
        <?php florian_header_center_show(); ?>
      </div>

      <div class="header-right">
        <?php florian_header_right_show(); ?>
      </div>
    </div>
  </div>

</div>
<?php florian_menu_below_header_show(); ?>
</header>
<?php endif; ?>
<?php
// Site Header Banner
florian_banner_show('below_header');
?>
