(function($){
$(document).ready(function() {

	'use strict';

	$('.mgt-mega-menu .mgt-menu-bg-image').each(function( index ) {
		$(this).attr('style', ($(this).attr('data-style')));
	});
	
    $('.mgt-mega-menu .nav .menu-item sup').each(function( index ) {
		$(this).attr('style', ($(this).attr('data-style')));
	});
	
});
})(jQuery);