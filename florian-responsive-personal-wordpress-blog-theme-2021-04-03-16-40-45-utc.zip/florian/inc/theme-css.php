<?php

	add_action( 'wp_enqueue_scripts', 'florian_enqueue_dynamic_styles', '999' );

    if(!function_exists('florian_enqueue_dynamic_styles')):
	function florian_enqueue_dynamic_styles( ) {

        require_once(ABSPATH . 'wp-admin/includes/file.php'); // required to use WP_Filesystem();

        WP_Filesystem();

        global $wp_filesystem;

		if ( function_exists( 'is_multisite' ) && is_multisite() ){
            $cache_file_name = 'style-cache-'.wp_get_theme()->get('TextDomain').'-b' . get_current_blog_id();
        } else {
            $cache_file_name = 'style-cache-'.wp_get_theme()->get('TextDomain');
        }

        // Customizer preview
        if(is_customize_preview()) {
            if ( function_exists( 'is_multisite' ) && is_multisite() ){
                $cache_file_name = 'preview-cache-'.wp_get_theme()->get('TextDomain').'-b' . get_current_blog_id();
            } else {
                $cache_file_name = 'preview-cache-'.wp_get_theme()->get('TextDomain');
            }
        }

        $wp_upload_dir = wp_upload_dir();

        $css_cache_file = $wp_upload_dir['basedir'].'/'.$cache_file_name.'.css';

        $css_cache_file_url = $wp_upload_dir['baseurl'].'/'.$cache_file_name.'.css';

        $themeoptions_saved_date = get_option( 'themeoptions_saved_date', 1 );
        $cache_saved_date = get_option( 'cache_css_saved_date', 0 );

		if( file_exists( $css_cache_file ) ) {
			$cache_status = 'exist';

            if($themeoptions_saved_date > $cache_saved_date) {
                $cache_status = 'no-exist';
            }

		} else {
			$cache_status = 'no-exist';
		}

        if ( defined('DEMO_MODE') ) {
            $cache_status = 'no-exist';
        }

        if(is_customize_preview()) {
            $cache_status = 'no-exist';
        }

		if ( $cache_status == 'exist' ) {

			wp_register_style( $cache_file_name, $css_cache_file_url, array(), $cache_saved_date);
			wp_enqueue_style( $cache_file_name );

		} else {

			$out = '/* Cache file created at '.date('Y-m-d H:i:s').' */';

			$generated = microtime(true);

			$out .= florian_get_css();

			$out = str_replace( array( "\t", "
", "\n", "  ", "   ", ), array( "", "", " ", " ", " ", ), $out );

			$out .= '/* CSS Generator Execution Time: ' . floatval( ( microtime(true) - $generated ) ) . ' seconds */';

            // FS_CHMOD_FILE required by WordPress guideliness - https://codex.wordpress.org/Filesystem_API#Using_the_WP_Filesystem_Base_Class
            if ( defined( 'FS_CHMOD_FILE' ) ) {
                $chmod_file = FS_CHMOD_FILE;
            } else {
                $chmod_file = ( 0644 & ~ umask() );
            }

			if ( $wp_filesystem->put_contents( $css_cache_file, $out, $chmod_file) ) {

				wp_register_style( $cache_file_name, $css_cache_file_url, array(), $cache_saved_date);
				wp_enqueue_style( $cache_file_name );

                // Update save options date
                $option_name = 'cache_css_saved_date';

                $new_value = microtime(true) ;

                if ( get_option( $option_name ) !== false ) {

                    // The option already exists, so we just update it.
                    update_option( $option_name, $new_value );

                } else {

                    // The option hasn't been added yet. We'll add it with $autoload set to 'no'.
                    $deprecated = null;
                    $autoload = 'no';
                    add_option( $option_name, $new_value, $deprecated, $autoload );
                }
			}

		}
	}
    endif;

    if(!function_exists('florian_get_css')):
	function florian_get_css() {
		// ===
		ob_start();
    ?>
    <?php
    // THEME OPTIONS DEFAULTS FOR CSS

    // Header height
    $header_height = get_theme_mod('header_height', 200);

    // Logo width
    $logo_width = get_theme_mod( 'logo_width', 135 );

    // Slider height
    $slider_height = get_theme_mod('slider_height', 500);

    // Main Menu paddings
    $mainmenu_paddings = get_theme_mod('mainmenu_paddings', '20px');

    // Top Menu paddings
    $topmenu_paddings = get_theme_mod('topmenu_paddings', '10px');

    ?>
    header .col-md-12 {
        height: <?php echo esc_attr($header_height); ?>px;
    }
    .navbar .nav > li {
        padding-top: <?php echo esc_attr($mainmenu_paddings); ?>;
        padding-bottom: <?php echo esc_attr($mainmenu_paddings); ?>;
    }
    .nav > li > .sub-menu {
        margin-top: <?php echo esc_attr($mainmenu_paddings); ?>;
    }
    .header-menu li a,
    .header-info-text,
    .header-menu .menu-top-menu-container-toggle {
        padding-top: <?php echo esc_attr($topmenu_paddings); ?>;
        padding-bottom: <?php echo esc_attr($topmenu_paddings); ?>;
    }
    .header-menu .menu-top-menu-container-toggle + div {
        top: calc(<?php echo esc_attr($topmenu_paddings); ?> + <?php echo esc_attr($topmenu_paddings); ?> + 20px);
    }
    <?php
    // Retina logo
    ?>

    header .logo-link img {
        width: <?php echo esc_attr($logo_width); ?>px;
    }
    .florian-blog-posts-slider .florian-post-list .florian-post .florian-post-image,
    .florian-blog-posts-slider .florian-post-list .florian-post .florian-post-image-wrapper,
    .florian-blog-posts-slider {
        height: <?php echo esc_attr($slider_height); ?>px;
    }
    @media (min-width: 1024px)  {
        body.single-post.blog-post-header-with-bg.blog-post-transparent-header-enable .container-fluid.container-page-item-title.with-bg .page-item-title-single,
        body.page.blog-post-header-with-bg.blog-post-transparent-header-enable .container-fluid.container-page-item-title.with-bg .page-item-title-single {
            padding-top: <?php echo intval(190+$header_height); ?>px;
        }
    }

    /**
    * Theme Google Font
    **/
    <?php
    // Logo text font
    if ( get_theme_mod( 'logo_text', true ) == true && get_theme_mod( 'logo_text_title', '' ) !== '' ) {

    $logo_text_font = get_theme_mod( 'logo_text_font', array(
        'font-family'    => 'Cormorant Garamond',
        'font-size'    => '62px',
        'variant'        => 'regular',
        'color'          => '#000000',
    ));

    ?>
        header .logo-link.logo-text {
            font-family: '<?php echo esc_attr($logo_text_font['font-family']); ?>';
            <?php echo esc_attr(florian_get_font_style_css($logo_text_font['variant'])); ?>
            font-size: <?php echo esc_attr($logo_text_font['font-size']); ?>;
            color: <?php echo esc_attr($logo_text_font['color']); ?>;
        }
        <?php
    }

    // Fonts and default fonts configuration

    // Headers font
    $headers_font = get_theme_mod('headers_font', array(
        'font-family'    => 'Cormorant Garamond',
        'variant'        => 'regular',
    ));

    // Body font
    $body_font = get_theme_mod('body_font', array(
        'font-family'    => 'Noto Serif',
        'variant'        => 'regular',
        'font-size'      => '15px',
    ));

    // Additional font
    $additional_font = get_theme_mod('additional_font', array(
        'font-family'    => 'Karla',
        'variant'        => 'regular',
    ));

    ?>
    h1, h2, h3, h4, h5, h6,
    .blog-post .format-quote .entry-content:before,
    blockquote:before,
    blockquote,
    .blog-post .format-quote .entry-content,
    .sidebar .widget .post-title,
    .woocommerce ul.cart_list li a, .woocommerce ul.product_list_widget li a,
    .widget_recent_entries li,
    .widget_recent_comments li,
    .widget_archive li,
    .widget_categories li,
    .widget_meta li,
    .widget_pages li,
    .widget_rss li,
    .comment-metadata .author,
    .author-bio strong,
    .blog-post-related-single .blog-post-related-title,
    .blog-post-related-item .blog-post-related-title,
    .navigation-post .nav-post-name,
    .single-post .blog-post-related h5,
    .sidebar .widgettitle,
    .post-worthreading-post-container .post-worthreading-post-title {
        font-family: '<?php echo esc_attr($headers_font['font-family']); ?>';
        <?php echo esc_attr(florian_get_font_style_css($headers_font['variant'])); ?>
    }
    body {
        font-family: '<?php echo esc_attr($body_font['font-family']); ?>';
        <?php echo esc_attr(florian_get_font_style_css($body_font['variant'])); ?>
        font-size: <?php echo esc_attr($body_font['font-size']); ?>;
    }
    .additional-font,
    .btn,
    input[type="submit"],
    .woocommerce #content input.button,
    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce-page #content input.button,
    .woocommerce-page #respond input#submit,
    .woocommerce-page a.button,
    .woocommerce-page button.button,
    .woocommerce-page input.button,
    .woocommerce a.added_to_cart,
    .woocommerce-page a.added_to_cart,
    .wp-block-button a.wp-block-button__link,
    .header-menu,
    .mainmenu-belowheader li.menu-item > a,
    .footer-menu,
    .florian-post .florian-post-details .florian-post-category,
    .florian-post .florian-post-info,
    .florian-post-list .florian-post-details .florian-post-category,
    .sidebar .widget .post-categories,
    .blog-post .post-categories,
    .page-item-title-single .post-categories,
    .blog-post-related.blog-post-related-loop .blog-post-related-item .blog-post-related-category,
    .page-item-title-archive p,
    .florian-post-list .florian-post-details .florian-post-info,
    .post-subtitle-container,
    .sidebar .widget .post-date,
    .page-item-title-single .post-date,
    .blog-post-related.blog-post-related-loop .blog-post-related-item .blog-post-related-date,
    .blog-post .tags,
    .blog-post.blog-post-single .post-info,
    .blog-post .post-info,
    .navigation-post .nav-post-title,
    .post-worthreading-post-wrapper .post-worthreading-post-button,
    .comment-metadata .date,
    .footer-instagram-wrapper .footer-instagram-title,
    .florian-blog-posts-slider .florian-post-counter,
    header .header-blog-info {
        font-family: '<?php echo esc_attr($additional_font['font-family']); ?>';
        <?php echo esc_attr(florian_get_font_style_css($additional_font['variant'])); ?>
    }

    /**
    * Colors and color skins
    */
    <?php
    $color_skin = get_theme_mod('color_skin', 'none');

    // Demo settings
    if ( defined('DEMO_MODE') && isset($_GET['color_skin']) ) {
      $color_skin = $_GET['color_skin'];
    }

    // Use panel settings
    if($color_skin == 'none') {

        $color_text = get_theme_mod('color_text', '#333333');
        $color_main = get_theme_mod('color_main', '#bd9e81');
        $color_button_hover = get_theme_mod('color_button_hover', '#000000');
        $color_topmenu_bg =  get_theme_mod('color_topmenu_bg', '#FFFFFF');
        $color_topmenu_dark_bg = get_theme_mod('color_topmenu_dark_bg', '#000000');
        $color_mainmenu_bg = get_theme_mod('color_mainmenu_bg', '#FFFFFF');
        $color_mainmenu_submenu_bg = get_theme_mod('color_mainmenu_submenu_bg', '#FFFFFF');
        $color_mainmenu_link = get_theme_mod('color_mainmenu_link', '#000000');
        $color_mainmenu_link_hover = get_theme_mod('color_mainmenu_link_hover', '#bd9e81');
        $color_mainmenu_submenu_link = get_theme_mod('color_mainmenu_submenu_link', '#000000');
        $color_mainmenu_submenu_link_hover = get_theme_mod('color_mainmenu_submenu_link_hover', '#bd9e81');
        $color_footer_bg = get_theme_mod('color_footer_bg', '#FFFFFF');
        $color_footer_dark_bg = get_theme_mod('color_footer_dark_bg', '#000000');
        $color_footer_sidebar_bg = get_theme_mod('color_footer_sidebar_bg', '#3C3D41');
        $color_slider_bg = get_theme_mod('color_slider_bg', '#F8F8F8');
        $color_slider_text = get_theme_mod('color_slider_text', '#000000');

    } else {

        // Same colors for all skins
        $color_text = '#000000';
        $color_button_hover = '#000000';
        $color_topmenu_bg = '#FFFFFF';
        $color_topmenu_dark_bg = '#000000';
        $color_mainmenu_bg = '#FFFFFF';
        $color_mainmenu_submenu_bg = '#FFFFFF';
        $color_mainmenu_link = '#000000';
        $color_mainmenu_submenu_link = '#000000';
        $color_mainmenu_submenu_link_hover = '#bd9e81';
        $color_footer_bg = '#FFFFFF';
        $color_footer_dark_bg = '#000000';
        $color_footer_sidebar_bg = '#3C3D41';
        $color_slider_bg = '#F8F8F8';
        $color_slider_text = '#000000';
    }

    // Default skin
    if($color_skin == 'default') {

        $color_main = '#bd9e81';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Black skin
    if($color_skin == 'black') {

        $color_main = '#444444';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Grey sking
    if($color_skin == 'grey') {

        $color_main = '#8e9da5';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Light blue skin
    if($color_skin == 'lightblue') {

        $color_main = '#A2C6EA';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Blue skin
    if($color_skin == 'blue') {

        $color_main = '#346DF4';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Red
    if($color_skin == 'red') {

        $color_main = '#D43034';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Green
    if($color_skin == 'green') {

        $color_main = '#00BC8F';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Orange
    if($color_skin == 'orange') {

        $color_main = '#ec9f2e';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // RedOrange
    if($color_skin == 'redorange') {

        $color_main = '#F2532F';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    // Brown
    if($color_skin == 'brown') {

        $color_main = '#C3A36B';
        $color_mainmenu_link_hover = $color_main;
        $color_mainmenu_submenu_link_hover = $color_main;

    }
    ?>
    <?php
    // Body background
    $body_background = get_theme_mod( 'body_background', false );

    if(!empty($body_background['background-image'])): ?>
    body {
        <?php
        echo 'background-image: url('.esc_url($body_background['background-image']).');';
        echo 'background-repeat: '.$body_background['background-repeat'].';';
        echo 'background-position: '.$body_background['background-position'].';';
        echo 'background-size: '.$body_background['background-size'].';';
        echo 'background-attachment: '.$body_background['background-attachment'].';';
        ?>
    }
    <?php endif; ?>
    <?php
    // Header background image
    $header_background = get_theme_mod( 'header_background', false );
    ?>
    header {
        background-color: <?php echo esc_attr($header_background['background-color']); ?>;
    }
    <?php
    if(!empty($header_background['background-image'])): ?>
    header {
        <?php
        echo 'background-image: url('.esc_url($header_background['background-image']).');';
        echo 'background-repeat: '.$header_background['background-repeat'].';';
        echo 'background-position: '.$header_background['background-position'].';';
        echo 'background-size: '.$header_background['background-size'].';';
        echo 'background-attachment: '.$header_background['background-attachment'].';';
        ?>
    }
    .container-fluid.container-page-item-title,
    .florian-blog-posts-slider {
        margin-top: 0;
    }
    .mainmenu-belowheader:not(.fixed),
    .mainmenu-belowheader:not(.fixed) .navbar {
        background-color: transparent!important;
    }
    <?php endif; ?>

    body {
        color: <?php echo esc_html($color_text); ?>;
        background-color: <?php echo esc_html($body_background['background-color']); ?>;
    }
    .blog-post .blog-post-thumb + .post-content,
    .sidebar .widget.widget_florian_posts_slider .widget-post-slider-wrapper .widget-post-details-wrapper,
    .navigation-paging .wp-pagenavi a, .navigation-paging .wp-pagenavi span.current, .navigation-paging .wp-pagenavi span.extend {
        background-color: <?php echo esc_html($body_background['background-color']); ?>;
    }
    a.btn,
    .btn,
    .btn:focus,
    input[type="submit"],
    .woocommerce #content input.button,
    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce-page #content input.button,
    .woocommerce-page #respond input#submit,
    .woocommerce-page a.button,
    .woocommerce-page button.button,
    .woocommerce-page input.button,
    .woocommerce a.added_to_cart,
    .woocommerce-page a.added_to_cart,
    .woocommerce #content input.button.alt:hover,
    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce-page #content input.button.alt:hover,
    .woocommerce-page #respond input#submit.alt:hover,
    .woocommerce-page a.button.alt:hover,
    .woocommerce-page button.button.alt:hover,
    .woocommerce-page input.button.alt:hover,
    .btn:active,
    .btn-primary,
    .btn-primary:focus,
    .btn.alt:hover,
    .btn.btn-black:hover,
    .btn.btn-bordered:hover,
    header .header-promo-content .btn:hover,
    .blog-post .tags a:hover,
    .blog-post-related-item-details,
    .blog-post .sticky-post-badge,
    .post-social-wrapper .post-social-title a:hover,
    .sidebar .widget_calendar th,
    .sidebar .widget_calendar tfoot td,
    .sidebar .widget_tag_cloud .tagcloud a:hover,
    .sidebar .widget_product_tag_cloud .tagcloud a:hover,
    .comment-meta .reply a:hover,
    body .owl-theme .owl-controls .owl-page.active span,
    body .owl-theme .owl-controls.clickable .owl-page:hover span,
    body .owl-theme .owl-dots .owl-dot.active span,
    body .owl-theme .owl-dots .owl-dot:hover span,
    body .ig_popup.ig_inspire .ig_button,
    body .ig_popup.ig_inspire input[type="submit"],
    body .ig_popup.ig_inspire input[type="button"],
    .homepage-welcome-block .background-theme,
    .wp-block-button a.wp-block-button__link,
    .blog-post .blog-post-thumb:not(.blog-post-thumb-media),
    .florian-post .florian-post-image-wrapper,
    .blog-post-list-layout.blog-post .blog-post-thumb-wrapper:not(.blog-post-thumb-wrapper-media),
    .social-icons-wrapper a:hover,
    .sidebar .widget.widget_florian_recent_entries li .widget-post-thumb-wrapper-container,
    .sidebar .widget.widget_florian_recent_entries li .widget-post-thumbsmall-wrapper-container,
    .sidebar .widget.widget_florian_posts_slider .widget-post-slider-wrapper .widget-post-thumb-wrapper-container,
    .post-worthreading-post-container .post-worthreading-post-image,
    .blog-post-list-layout.blog-post .blog-post-thumb-list-advanced,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-range,
    .woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
    .sidebar .widget.widget_florian_popular_entries li .widget-post-thumbsmall-wrapper-container,
    .sidebar .widget.widget_florian_popular_entries .widget-post-position {
        background-color: <?php echo esc_html($color_main); ?>;
    }
    a,
    .container-fluid.container-page-item-title.with-bg .post-info-share .post-social a:hover,
    header .header-post-content .header-post-details .header-post-title a:hover,
    .header-info-text a:hover,
    .header-menu .header-menu-search a:hover,
    .header-menu li a:hover,
    .blog-post .post-author a:hover,
    .blog-post .post-header-title sup,
    .blog-post .post-header-title a:hover,
    .author-bio .author-social-icons li a:hover,
    .blog-post-related.blog-post-related-loop .blog-post-related-item .blog-post-related-title a:hover,
    .post-social-wrapper .post-social a:hover,
    .navigation-post .nav-post-prev:hover .nav-post-name,
    .navigation-post .nav-post-next:hover .nav-post-name,
    .blog-masonry-layout .blog-post.content-block .sticky:not(.sticky-post-without-image) .post-info .post-social a:hover,
    .blog-masonry-layout .blog-post.content-block .sticky:not(.sticky-post-without-image) .post-info .post-info-comments a:hover,
    .footer-sidebar-2.sidebar .widget a:hover,
    footer a:hover,
    .sidebar .widget_text a,
    .florian-post .florian-post-details .florian-post-title h5:hover,
    .florian-editorspick-post-list-wrapper .florian-editorspick-post .florian-editorspick-post-title a:hover,
    body .select2-results .select2-highlighted,
    .florian-theme-block > h2,
    .florian-editorspick-post-list-wrapper .florian-editorspick-post .florian-editorspick-post-category,
    .page-item-title-single .post-categories,
    .florian-post-list .florian-post-details .florian-post-title h2:hover,
    .btn.btn-text:hover,
    .navigation-paging.navigation-post a:hover,
    .florian-editorspick-post-list-wrapper .florian-editorspick-post .florian-editorspick-post-author a:hover,
    .sidebar .widget .post-title:hover,
    .post-worthreading-post-container .post-worthreading-post-title a:hover,
    .florian-about-block .florian-post .florian-post-details .florian-post-category {
        color: <?php echo esc_html($color_main); ?>;
    }
    header .header-promo-content .btn:hover,
    .sidebar .widget_calendar tbody td a,
    .florian-post-list-nav .florian-post-list-nav-prev,
    .wp-block-button a.wp-block-button__link,
    .blog-post-reading-progress,
    a.btn,
    .btn,
    .btn:focus,
    input[type="submit"],
    .woocommerce #content input.button,
    .woocommerce #respond input#submit,
    .woocommerce a.button,
    .woocommerce button.button,
    .woocommerce input.button,
    .woocommerce-page #content input.button,
    .woocommerce-page #respond input#submit,
    .woocommerce-page a.button,
    .woocommerce-page button.button,
    .woocommerce-page input.button,
    .woocommerce a.added_to_cart,
    .woocommerce-page a.added_to_cart,
    .wp-block-button a.wp-block-button__link,
    .woocommerce #content input.button.alt:hover,
    .woocommerce #respond input#submit.alt:hover,
    .woocommerce a.button.alt:hover,
    .woocommerce button.button.alt:hover,
    .woocommerce input.button.alt:hover,
    .woocommerce-page #content input.button.alt:hover,
    .woocommerce-page #respond input#submit.alt:hover,
    .woocommerce-page a.button.alt:hover,
    .woocommerce-page button.button.alt:hover,
    .woocommerce-page input.button.alt:hover,
    .btn.btn-black:hover,
    .btn:active,
    .btn-primary,
    .btn-primary:focus,
    .btn.alt:hover,
    .btn.btn-bordered:hover {
        border-color: <?php echo esc_html($color_main); ?>;
    }
    .woocommerce #content input.button.alt,
    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt,
    .woocommerce-page #content input.button.alt,
    .woocommerce-page #respond input#submit.alt,
    .woocommerce-page a.button.alt,
    .woocommerce-page button.button.alt,
    .woocommerce-page input.button.alt,
    .btn:hover,
    .btn.btn-white:hover,
    input[type="submit"]:hover,
    .woocommerce #content input.button:hover,
    .woocommerce #respond input#submit:hover,
    .woocommerce a.button:hover,
    .woocommerce button.button:hover,
    .woocommerce input.button:hover,
    .woocommerce-page #content input.button:hover,
    .woocommerce-page #respond input#submit:hover,
    .woocommerce-page a.button:hover,
    .woocommerce-page button.button:hover,
    .woocommerce-page input.button:hover,
    .btn.alt,
    .btn.btn-black,
    .btn-primary:hover,
    .btn-primary:active,
    .footer-instagram-wrapper .footer-instagram-title,
    .social-icons-wrapper a,
    .florian-popular-post-list-wrapper .florian-popular-post-list-nav .florian-popular-post-list-nav-prev, .florian-popular-post-list-wrapper .florian-popular-post-list-nav .florian-popular-post-list-nav-next,
    body .owl-theme .owl-controls .owl-nav div {
        background-color: <?php echo esc_html($color_button_hover); ?>;
    }
    .woocommerce #content input.button.alt,
    .woocommerce #respond input#submit.alt,
    .woocommerce a.button.alt,
    .woocommerce button.button.alt,
    .woocommerce input.button.alt,
    .woocommerce-page #content input.button.alt,
    .woocommerce-page #respond input#submit.alt,
    .woocommerce-page a.button.alt,
    .woocommerce-page button.button.alt,
    .woocommerce-page input.button.alt,
    .btn:hover,
    .btn.btn-white:hover,
    input[type="submit"]:hover,
    .woocommerce #content input.button:hover,
    .woocommerce #respond input#submit:hover,
    .woocommerce a.button:hover,
    .woocommerce button.button:hover,
    .woocommerce input.button:hover,
    .woocommerce-page #content input.button:hover,
    .woocommerce-page #respond input#submit:hover,
    .woocommerce-page a.button:hover,
    .woocommerce-page button.button:hover,
    .woocommerce-page input.button:hover,
    .btn.alt,
    .btn.btn-black,
    .btn-primary:hover,
    .btn-primary:active {
        border-color: <?php echo esc_html($color_button_hover); ?>;
    }
    .mainmenu-belowheader {
        background-color: <?php echo esc_html($color_mainmenu_bg); ?>;
    }
    .nav > li .sub-menu {
        background-color: <?php echo esc_html($color_mainmenu_submenu_bg); ?>;
    }
    .nav .sub-menu li.menu-item > a {
        color: <?php echo esc_html($color_mainmenu_submenu_link); ?>;
    }
    .nav .sub-menu li.menu-item > a:hover {
        color: <?php echo esc_html($color_mainmenu_submenu_link_hover); ?>;
    }
    .navbar .nav > li > a {
        color: <?php echo esc_html($color_mainmenu_link); ?>;
    }
    .navbar .nav > li > a:hover {
        color: <?php echo esc_html($color_mainmenu_link_hover); ?>;
    }
    footer {
        background-color: <?php echo esc_html($color_footer_bg); ?>;
    }
    footer.footer_black {
        background-color: <?php echo esc_html($color_footer_dark_bg); ?>;
    }
    .container-fluid-footer {
        background-color: <?php echo esc_html($color_footer_sidebar_bg); ?>;
    }
    .header-menu-bg,
    .header-menu-bg .header-menu li ul {
        background-color: <?php echo esc_html($color_topmenu_bg); ?>;
    }
    .header-menu-bg.menu_black,
    .header-menu-bg.menu_black .header-menu .menu-top-menu-container-toggle + div,
    .header-menu-bg.menu_black .header-menu li ul {
        background-color: <?php echo esc_html($color_topmenu_dark_bg); ?>;
    }
    .florian-blog-posts-slider-bg,
    .florian-blog-posts-slider {
        background-color: <?php echo esc_html($color_slider_bg); ?>;
    }

    <?php
    	$out = ob_get_clean();

		$out .= ' /*' . date("Y-m-d H:i") . '*/';
		/* RETURN */
		return $out;
	}
    endif;
