<?php
/**
 * Plugin recomendations
 **/
require_once(get_template_directory().'/inc/class-tgm-plugin-activation.php');

if(!function_exists('florian_register_required_plugins')):
function florian_register_required_plugins() {

    /**
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(
        array(
            'name'                  => esc_html__('Florian Custom Metaboxes', 'florian'), // The plugin name
            'slug'                  => 'cmb2', // The plugin slug (typically the folder name)
            'source'                => get_template_directory() . '/inc/plugins/cmb2.zip', // The plugin source
            'required'              => true, // If false, the plugin is only 'recommended' instead of required
            'version'               => '2.7.0', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
        ),
        array(
            'name'                  => esc_html__('Florian Theme Settings (Kirki Toolkit)', 'florian'),
            'slug'                  => 'kirki',
            'required'              => true,
        ),
        array(
            'name'                  => esc_html__('Florian Theme Addons', 'florian'), // The plugin name
            'slug'                  => 'florian-theme-addons', // The plugin slug (typically the folder name)
            'source'                => get_template_directory() . '/inc/plugins/florian-theme-addons.zip', // The plugin source
            'required'              => true, // If false, the plugin is only 'recommended' instead of required
            'version'               => '1.4', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
        ),
        array(
            'name'                  => esc_html__('Florian Page Navigation', 'florian'), // The plugin name
            'slug'                  => 'wp-pagenavi', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('Florian Translation Manager', 'florian'), // The plugin name
            'slug'                  => 'loco-translate', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('Instagram Feed', 'florian'), // The plugin name
            'slug'                  => 'instagram-feed', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('MailChimp for WordPress', 'florian'), // The plugin name
            'slug'                  => 'mailchimp-for-wp', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('WordPress LightBox', 'florian'), // The plugin name
            'slug'                  => 'responsive-lightbox', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('Contact Form 7', 'florian'), // The plugin name
            'slug'                  => 'contact-form-7', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        ),
        array(
            'name'                  => esc_html__('Regenerate Thumbnails', 'florian'), // The plugin name
            'slug'                  => 'regenerate-thumbnails', // The plugin slug (typically the folder name)
            'required'              => false, // If false, the plugin is only 'recommended' instead of required
        )

    );

    // Add Gutenberg for old WordPress versions
    if(version_compare(get_bloginfo('version'), '5.0', "<")) {
        $plugins[] = array(
            'name'                  => esc_html__('Gutenberg - Advanced WordPress Content Editor', 'florian'),
            'slug'                  => 'gutenberg',
            'required'              => false,
        );
    }

    /**
     * Array of configuration settings. Amend each line as needed.
     * If you want the default strings to be available under your own theme domain,
     * leave the strings uncommented.
     * Some of the strings are added into a sprintf, so see the comments at the
     * end of each line for what each argument will be.
     */
    $config = array(
        'domain'            => 'florian',           // Text domain - likely want to be the same as your theme.
        'default_path'      => '',                          // Default absolute path to pre-packaged plugins
        'menu'              => 'install-required-plugins',  // Menu slug
        'has_notices'       => true,                        // Show admin notices or not
        'dismissable'  => true,
        'is_automatic'      => false,                       // Automatically activate plugins after installation or not
        'message'           => ''                          // Message to output right before the plugins table
    );

    tgmpa( $plugins, $config );

}
endif;
add_action('tgmpa_register', 'florian_register_required_plugins');

/**
 * Header banner 1 display
 */
if(!function_exists('florian_header_promo_show')):
function florian_header_promo_show() {

    echo '<div class="header-promo-content">'.do_shortcode(get_theme_mod('header_banner_1_html')).'</div>'; // This is safe place and we can't use wp_kses_post or other esc_ functions here because this is ads area where user may use Google Adsense and other Java Script banners code with <script> inside.
}
endif;

/**
 * Header banner 2 display
 */
if(!function_exists('florian_header_promo2_show')):
function florian_header_promo2_show() {

    echo '<div class="header-promo-content">'.do_shortcode(get_theme_mod('header_banner_2_html')).'</div>'; // This is safe place and we can't use wp_kses_post or other esc_ functions here because this is ads area where user may use Google Adsense and other Java Script banners code with <script> inside.
}
endif;

/**
 * Header logo display
 */
if(!function_exists('florian_logo_show')):
function florian_logo_show() {

    // Header tagline style
    $tag_line_style = get_theme_mod('header_tagline_style', 'regular');

    // Text logo
    if ( get_theme_mod( 'logo_text', false ) == true && (get_theme_mod( 'logo_text_title', '' ) !== '') ) {
        ?>
        <div class="logo"><a class="logo-link logo-text" href="<?php echo esc_url(home_url()); ?>"><?php echo html_entity_decode(wp_kses_post(get_theme_mod( 'logo_text_title', true )));?></a>
        <?php
          if(get_bloginfo('description')!=='' && get_theme_mod( 'header_tagline', true ) == true ) {
            echo '<div class="header-blog-info header-blog-info-'.esc_attr($tag_line_style).'">';
            bloginfo('description');
            echo '</div>';
          }
        ?>
        </div>
        <?php
    // Image logo
    } else {
        ?>
        <div class="logo">
        <a class="logo-link" href="<?php echo  esc_url(home_url('/')); ?>"><img src="<?php echo get_header_image(); ?>" alt="<?php bloginfo('name'); ?>" class="regular-logo"><img src="<?php if ( get_theme_mod( 'florian_header_transparent_logo' ) ) { echo esc_url( get_theme_mod( 'florian_header_transparent_logo' )); } else { echo esc_url(get_header_image()); }  ?>" alt="<?php bloginfo('name'); ?>" class="light-logo"></a>
        <?php
          if(get_bloginfo('description')!=='' && get_theme_mod( 'header_tagline', true ) == true ) {
            echo '<div class="header-blog-info header-blog-info-'.esc_attr($tag_line_style).'">';
            bloginfo('description');
            echo '</div>';
          }
        ?>
        </div>
        <?php
    }

    ?>

    <?php
}
endif;

/**
 * Main Menu display
 */
if(!function_exists('florian_menu_below_header_show')):
function florian_menu_below_header_show() {

    // MainMenu styles
    $menu_add_class = '';

    $menu_add_class .= ' mainmenu-'.esc_html(get_theme_mod('mainmenu_font_decoration', 'uppercase'));

    $menu_add_class .= ' mainmenu-'.esc_html(get_theme_mod('mainmenu_font_size', 'normalfont'));

    $menu_add_class .= ' mainmenu-'.esc_html(get_theme_mod('mainmenu_font_weight', 'regularfont'));

    $menu_add_class .= ' mainmenu-'.esc_html(get_theme_mod('mainmenu_font_letterspacing', 'letterspacing-disable'));

    $menu_add_class .= ' mainmenu-'.esc_html(get_theme_mod('mainmenu_arrow_style', 'downarrow'));


    if(get_theme_mod('mainmenu_borders', true) == false) {
        $menu_add_class .= ' mainmenu-borders-disable';
    }

    if(get_theme_mod('mainmenu_margin_bottom', true) == true) {
        $menu_add_class .= ' mainmenu-with-margin';
    }

    // Center menu
    $menu_add_class .= ' menu-center';

    if(get_theme_mod('header_sticky', true) == true) {

      $menu_add_class .= ' sticky-header';

    }

    ?>

    <?php
    // Main Menu

    $menu = wp_nav_menu(
        array (
            'theme_location'  => 'primary',
            'echo' => false,
            'fallback_cb'    => false,
        )
    );

    if(get_theme_mod('module_mega_menu', true)) {
         $add_class = ' mgt-mega-menu';
         $menu_walker = new florian_megamenu_walker;
    } else {
         $add_class = '';
         $menu_walker = new florian_mainmenu_walker;
    }

    if (!empty($menu)):

    ?>
    <div class="mainmenu-belowheader<?php echo esc_attr($menu_add_class); ?> clearfix">
        <?php if(get_theme_mod('blog_post_reading_progress', false)): ?>
        <div class="blog-post-reading-progress"></div>
        <?php endif; ?>

        <?php if(get_theme_mod('header_sticky_logo', false) == true): ?>

        <?php florian_logo_show(); ?>

        <?php endif; ?>
        <div id="navbar" class="navbar navbar-default clearfix<?php echo esc_attr($add_class);?>">

          <div class="navbar-inner">
              <div class="container">

                  <div class="navbar-toggle" data-toggle="collapse" data-target=".collapse">
                    <?php esc_html_e( 'Menu', 'florian' ); ?>
                  </div>

                  <div class="navbar-center-wrapper">
                  <?php

                     wp_nav_menu(array(
                      'theme_location'  => 'primary',
                      'container_class' => 'navbar-collapse collapse',
                      'menu_class'      => 'nav',
                      'fallback_cb'    => false,
                      'walker'          => $menu_walker
                      ));

                  ?>
                  </div>

              </div>
          </div>

        </div>

    </div>
    <?php endif; ?>

    <?php
    // MainMenu Below header position END
}
endif;

/**
 * Social icons display
 */
if(!function_exists('florian_social_show')):
function florian_social_show($showtitles = false, $addwrapper = false) {

    $social_services_list = florian_social_services_list();

    $s_count = 0;

    $social_services_html = '';

    $social_icons = get_theme_mod('social_icons', array());

    foreach( $social_icons as $social_icon ) {

        $social_type = $social_icon['social_type'];
        $social_url = $social_icon['social_url'];

        if($showtitles) {
            $social_title = '<span>'.$social_services_list[$social_type].'</span>';
        } else {
            $social_title = '';
        }

        $social_services_html .= '<a href="'.esc_url($social_url).'" target="_blank" class="a-'.esc_attr($social_type).'"><i class="fa fa-'.esc_attr($social_type).'"></i>'.wp_kses_post($social_title).'</a>';
    }

    if($social_services_html !== '') {
        if($addwrapper) {
            echo wp_kses_post('<div class="social-icons-wrapper">'.$social_services_html.'</div>');
        } else {
            echo wp_kses_post($social_services_html);
        }
    }
}
endif;

/**
 * Top menu display
 */
if(!function_exists('florian_top_show')):
function florian_top_show() {
    ?>
    <?php if(get_theme_mod('topmenu_disable', false) == false):  ?>
    <?php
    $header_add_class = '';

    $header_top_menu_style = get_theme_mod('topmenu_style', 'menu_black');
    $header_add_class .= ' '.esc_attr($header_top_menu_style);

    $header_top_menu_uppercase = get_theme_mod('topmenu_uppercase', 'uppercase');
    $header_add_class .= ' header-menu-'.esc_attr($header_top_menu_uppercase);

    ?>
    <div class="header-menu-bg<?php echo esc_attr($header_add_class); ?>">
      <div class="header-menu">
        <div class="container">
          <div class="row">
            <?php if(get_theme_mod('topmenu_socialicons', true) == true) {
                $header_menu_col_class = 'col-md-6';
            } else {
                $header_menu_col_class = 'col-md-12';
            }
            ?>
            <div class="<?php echo esc_attr($header_menu_col_class); ?>">
              <div class="menu-top-menu-container-toggle"></div>
              <?php
              wp_nav_menu(array(
                'theme_location'  => 'top',
                'menu_class'      => 'links',
                'fallback_cb'    => false,
                ));
              ?>
            </div>
             <?php
            // Header social icons
            if(get_theme_mod('topmenu_socialicons', true)):
            ?>
            <div class="col-md-6">

                <div class="header-info-text">
                <?php
                // Top menu search
                if(get_theme_mod('search_position', 'top_menu') == 'top_menu'):
                ?>
                <a class="search-toggle-btn"><i class="fa fa-search" aria-hidden="true"></i></a>
                <?php endif; ?>
                <span><?php echo esc_html__('Follow us', 'florian'); ?></span>
                <?php florian_social_show(); ?>
                </div>

            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif;
}
endif;

/**
 * Header left part display
 */
if(!function_exists('florian_header_left_show')):
function florian_header_left_show() {

    // Show header banner
    if(get_theme_mod('header_banner_1_position', 'left') == 'left') {
        florian_header_promo_show();
    }

    // Show header banner
    if(get_theme_mod('header_banner_2_position', 'right') == 'left') {
        florian_header_promo2_show();
    }

    // Show header logo
    if(get_theme_mod('logo_position', 'center') == 'left') {
        florian_logo_show();
    }

}
endif;

/**
 * Header center part display
 */
if(!function_exists('florian_header_center_show')):
function florian_header_center_show() {

    // Show header banner
    if(get_theme_mod('header_banner_1_position', 'left') == 'center') {
        florian_header_promo_show();
    }

    // Show header banner
    if(get_theme_mod('header_banner_2_position', 'right') == 'center') {
        florian_header_promo2_show();
    }

    // Show header logo
    if(get_theme_mod('logo_position', 'center') == 'center') {
        florian_logo_show();
    }

}
endif;

/**
 * Header right part display
 */
if(!function_exists('florian_header_right_show')):
function florian_header_right_show() {

    // Show header logo
    if(get_theme_mod('logo_position', 'center') == 'right') {
        florian_logo_show();
    }

    // Show header banner
    if(get_theme_mod('header_banner_1_position', 'left') == 'right') {
        florian_header_promo_show();
    }

    // Show header banner
    if(get_theme_mod('header_banner_2_position', 'right') == 'right') {
        florian_header_promo2_show();
    }

}
endif;

/**
 * Homepage featured posts slider display
 */
if(!function_exists('florian_blog_modern_slider_show')):
function florian_blog_modern_slider_show() {

    if(get_theme_mod('slider_enable', false) == true): ?>

    <?php
    $slider_width = get_theme_mod('slider_width', 'boxed');

    $slider_text_color = get_theme_mod('slider_text_color', 'black');

    // Demo settings
    if ( defined('DEMO_MODE') && isset($_GET['slider_width']) ) {
        $slider_width = $_GET['slider_width'];
    }

    if($slider_width == 'fullwidth') {
        $bg_container_class = 'florian-blog-posts-slider-bg';
    } else {
        $bg_container_class = 'florian-blog-posts-slider-no-bg';
    }

    ?>

    <div class="<?php echo esc_attr($bg_container_class);?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="florian-blog-posts-slider florian-blog-posts-slider-text-color-<?php echo esc_html($slider_text_color); ?>">
    <?php

    // Custom slider
    if(get_theme_mod('slider_custom', false) == true) {
        echo '<div class="florian-custom-slider">'.do_shortcode(get_theme_mod('slider_custom_shortcode', '')).'</div>';
    } else {
    // Theme slider
        $posts_per_page = get_theme_mod('slider_limit', 30);

        if(get_theme_mod('slider_posts_type', 'featured') == 'featured') {
             $args = array(
              'posts_per_page'   => $posts_per_page,
              'orderby'          => 'date',
              'order'            => 'DESC',
              'meta_key'         => '_florian_post_featured',
              'meta_value'         => 'on',
              'post_type'        => 'post',
              'post_status'      => 'publish',
              'suppress_filters' => 0
            );
        }

        if(get_theme_mod('slider_posts_type', 'featured') == 'latest') {
             $args = array(
              'posts_per_page'   => $posts_per_page,
              'orderby'          => 'date',
              'order'            => 'DESC',
              'post_type'        => 'post',
              'post_status'      => 'publish',
              'suppress_filters' => 0
            );
        }

        $posts = get_posts( $args );

        $total_posts = sizeof($posts);

        if($total_posts > 0) {

          $slider_autoplay = get_theme_mod('slider_autoplay', '0');

          if($slider_autoplay > 0) {
              $slider_autoplay_bool = 'true';
          } else {
              $slider_autoplay_bool = 'false';
          }

          if($slider_autoplay == 1) {
              $slider_autoplay_class = ' autoplay ';
          } else {
              $slider_autoplay_class = ' ';
          }

          $slider_arrows = get_theme_mod('slider_arrows', true);

          if($slider_arrows == true) {
              $slider_arrows = 'true';
          } else {
              $slider_arrows = 'false';
          }

          echo '<div class="florian-post-list-wrapper'.esc_attr($slider_autoplay_class).' clearfix">';

          echo '<div id="florian-post-list" class="florian-post-list">';

          echo '<div class="owl-carousel">';

          $i = 0;

          foreach($posts as $post) {

              setup_postdata($post);

              $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'florian-blog-thumb');

              if(has_post_thumbnail( $post->ID )) {
                  $image_bg ='background-image: url('.$image[0].');';
              }
              else {
                  $image_bg = '';
              }

              $categories_list = get_the_category_list(', ', 0, $post->ID);

              echo '<div class="florian-post">';
              echo '<div class="florian-post-counter">'.esc_html($i+1).'/'.esc_html(sizeof($posts)).'</div>';
              echo '<div class="florian-post-image-wrapper">';
              echo '<div class="florian-post-image hover-effect-img" data-style="'.esc_attr($image_bg).'"><a href="'.esc_url(get_permalink($post->ID)).'"></a>';
              echo '</div>';
              echo '</div>';

              // Post details
              echo '<div class="florian-post-details">

                   <div class="florian-post-category">'.wp_kses_post($categories_list).'</div>
                   <div class="florian-post-title"><a href="'.esc_url(get_permalink($post->ID)).'"><h5>'.esc_html($post->post_title).'</h5></a></div>';

              echo '<div class="florian-post-info">
                   <div class="florian-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div>';

              if(get_theme_mod('blog_posts_author', false) == true) {
                  echo '<div class="florian-post-author">'.get_the_author_posts_link().'</div>';
              }

              echo '<div class="florian-post-button"><a class="btn alt" href="'.esc_url(get_permalink($post->ID)).'">'.esc_html__('View more', 'florian').'</a></div>';

              echo '</div>';
              echo '</div>';
              // END - Post details

              echo '</div>';

              $i++;

          }

          wp_reset_postdata();

          echo '</div>';
          echo '</div>';

          echo '</div>';

          if($total_posts > 1) {

              wp_add_inline_script( 'florian-script', '(function($){
              $(document).ready(function() {

                  "use strict";

                  var owlpostslider = $("#florian-post-list .owl-carousel").owlCarousel({
                      loop: true,
                      items: 1,
                      autoplay:'.esc_js($slider_autoplay_bool).',
                      autowidth: false,
                      autoplayTimeout:'.esc_js($slider_autoplay).',
                      autoplaySpeed: 1000,
                      navSpeed: 1000,
                      nav: '.esc_js($slider_arrows).',
                      dots: false,
                      navText: false,
                      responsive: {
                          1199:{
                              items:1
                          },
                          979:{
                              items:1
                          },
                          768:{
                              items:1
                          },
                          479:{
                              items:1
                          },
                          0:{
                              items:1
                          }
                      }
                  });

                  AOS.refresh();


              });})(jQuery);');



            } else {
                wp_add_inline_script( 'florian-script', '(function($){
                  $(document).ready(function() {

                     "use strict";

                     $("#florian-post-list .owl-carousel").show();

                     AOS.refresh();

                  });})(jQuery);');
            }
        }
    }

    ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif;

}
endif;

/**
 * Editors pick's block display
 */
if(!function_exists('florian_blog_editorspick_posts_show')):
function florian_blog_editorspick_posts_show() {

    if(get_theme_mod('editorspicks', false) == true):

    $posts_limit = 100;

    $args = array(
        'posts_per_page'   => $posts_limit,
        'orderby'          => 'date',
        'order'            => 'DESC',
        'meta_key'         => '_florian_post_editorspicks',
        'meta_value'         => 'on',
        'post_type'        => 'post',
        'post_status'      => 'publish',
        'suppress_filters' => 0
    );

    $posts = get_posts( $args );

    $total_posts = sizeof($posts);

    if($total_posts > 0) {

        echo '<div class="container florian-editorspick-wrapper">
              <div class="row">
              <div class="col-md-12">';

        echo '<div class="florian-editorspick-title"><h5>'.esc_html__('Handpicked posts', 'florian').'</h5></div>';

        echo '<div class="florian-editorspick-post-list-wrapper clearfix"'.florian_add_aos(false).'>';

        echo '<div id="florian-editorspick-post-list" class="florian-editorspick-post-list">';
        echo '<div class="row florian-editorspick-post-row">';

        $i = 0;

        $post_arr_id = rand(0, $total_posts-1);

        $post = $posts[$post_arr_id];

        setup_postdata($post);

        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'florian-blog-thumb');

        if(has_post_thumbnail( $post->ID )) {
            $image_bg ='background-image: url('.$image[0].');';
        }
        else {
            $image_bg = '';
        }

        $categories_list = get_the_category_list( ', ', 0, $post->ID );

        $limit = 50;

        $excerpt = explode(' ', get_the_excerpt($post->ID), $limit);
        if (count($excerpt)>=$limit) {
            array_pop($excerpt);
            $excerpt = implode(" ",$excerpt).'...';
        } else {
            $excerpt = implode(" ",$excerpt);
        }

        $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);

        echo '<div class="col-md-12">';
        echo '<div class="florian-post">';

        if(has_post_thumbnail( $post->ID )) {

            echo '<div class="florian-post-image-wrapper"><div class="florian-post-image hover-effect-img" data-style="'.esc_attr($image_bg).'"><a href="'.esc_url(get_permalink($post->ID)).'"></a></div></div>';
        }

        // Post details
        echo '
        <div class="florian-post-details">

            <div class="florian-post-category">'.wp_kses_post($categories_list).'</div>
            <div class="florian-post-title"><a href="'.esc_url(get_permalink($post->ID)).'"><h5>'.esc_html($post->post_title).'</h5></a></div>
            <div class="florian-post-info">
                <div class="florian-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div>';

                if(get_theme_mod('blog_posts_author', false) == true) {
                    echo '<div class="florian-post-author">'.get_the_author_posts_link().'</div>';
                }

            echo '
            </div>';

        echo '<div class="florian-editorspick-post-description">'.esc_html($excerpt).'</div>
             <div class="florian-editorspick-post-readmore"><a href="'.esc_url(get_permalink($post->ID)).'" class="btn alt">'.esc_html__('View more', 'florian').'</a></div>
             </div>';

        echo '</div>';
        echo '</div>';



        wp_reset_postdata();

        echo '</div>';
        echo '</div>';

        echo '</div>';

        echo '</div>';
        echo '</div>';

    }

    endif;
}
endif;

/**
 * Ads banner display
 */
if(!function_exists('florian_banner_show')):
function florian_banner_show($banner_id) {

    $banner_option_name = 'banner_'.$banner_id;
    $banner_content_name = 'banner_'.$banner_id.'_content';

    if(get_theme_mod($banner_option_name, false) == true) {

        echo '<div class="florian-bb-block florian-bb-block-'.$banner_id.' clearfix">';
        echo do_shortcode(get_theme_mod($banner_content_name, '')); // This is safe place and we can't use wp_kses_post or other esc_ functions here because this is ads area where user may use Google Adsense and other Java Script banners code with <script> inside.
        echo '</div>';
    }

}
endif;

/**
 * Welcome block display
 */
if(!function_exists('florian_welcome_block_show')):
function florian_welcome_block_show() {
    ?>
    <?php
    if(get_theme_mod('welcomeblock', false) && get_theme_mod('welcomeblock_html', '') !== '') {

        echo '<div class="container">';
        echo '<div class="homepage-welcome-block"'.florian_add_aos(false).'>';

        echo do_shortcode(wp_kses_post(get_theme_mod('welcomeblock_html', '')));

        echo '</div>';
        echo '</div>';
    }

}
endif;


/**
 * About block display
 */
if(!function_exists('florian_about_block_show')):
function florian_about_block_show() {
    ?>
    <?php if(get_theme_mod('aboutblock', false) && get_theme_mod('aboutblock_html', '') !== ''): ?>
    <?php
    $image_id = get_theme_mod('aboutblock_image', '');

    $about_image_data = wp_get_attachment_image_src( $image_id, 'full' );
    $about_image = $about_image_data[0];

    if(isset($about_image) && ($about_image !== '')) {
        $about_image_image_style = 'background-image: url('.$about_image.');';
    } else {
        $about_image_image_style = '';
    }
    ?>
        <div class="container">
            <div class="florian-about-block"<?php florian_add_aos();?>>
                <div class="florian-about-block-image" data-style="<?php echo esc_attr($about_image_image_style); ?>">
                </div>
                <div class="florian-about-block-text">
                    <?php echo do_shortcode(wp_kses_post(get_theme_mod('aboutblock_html', ''))); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php
}
endif;

/**
 * Homepage featured categories block display
 */
if(!function_exists('florian_featured_categories_block_show')):
function florian_featured_categories_block_show() {

    $categories = get_theme_mod('featured_categories', array());
    $categories_count = sizeof($categories);

    if(!empty($categories) && $categories_count > 0) {

        echo '<div class="florian-featured-categories-wrapper">';
        echo '<div class="container">';
        echo '<div class="row">';

        echo '<div class="col-md-12 florian-featured-categories-title"><h5>'.esc_html__('Featured Categories', 'florian').'</h5></div>';

        if($categories_count % 3 == 0) {
            $col_class = 'col-md-4';
        } else {
            $col_class = 'col-md-3';
        }

        foreach ($categories as $category) {

            $image_id = get_term_meta ( $category, 'category-image-id', true );

            $category_image_data = wp_get_attachment_image_src( $image_id, 'full' );
            $category_image = $category_image_data[0];

            if(isset($category_image) && ($category_image !== '')) {
                $category_image_image_style = 'background-image: url('.$category_image.');';
            } else {
                $category_image_image_style = '';
            }

            $category_link = get_category_link( $category );
            $category_title = get_the_category_by_ID( $category );

            echo '<div class="'.esc_attr($col_class).'">';
            echo '<div class="florian-featured-category" data-style="'.esc_attr($category_image_image_style).'"'.florian_add_aos(false).'>';
            echo '<a href="'.esc_url($category_link).'" class="florian-featured-category-link btn alt">'.esc_html($category_title).'</a>';
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

}
endif;

/**
 * Homepage latest posts block display
 */
if(!function_exists('florian_latest_posts_block_show')):
function florian_latest_posts_block_show() {

        $posts_limit = get_theme_mod('homepage_latest_posts_limit', 6);

        $args = array(
            'posts_per_page'   => $posts_limit,
            'order'            => 'DESC',
            'orderby' => 'meta_value',
            'post_type'        => 'post',
            'post_status'      => 'publish',
            'suppress_filters' => 0
        );

        $posts = get_posts( $args );

        $total_posts = sizeof($posts);

        if($total_posts > 0) {

            echo '<div class="florian-lastest-posts-wrapper">';
            echo '<div class="container">';
            echo '<div class="row">';

            echo '<div class="col-md-12 florian-lastest-posts-title"><h5>'.esc_html__('Latest Posts', 'florian').'</h5></div>';

            foreach($posts as $post) {

                setup_postdata($post);

                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'florian-blog-thumb');

                if(has_post_thumbnail( $post->ID )) {
                    $image_bg ='background-image: url('.$image[0].');';
                    $post_class = '';
                }
                else {
                    $image_bg = '';
                    $post_class = ' florian-post-no-image';
                }

                $categories_list = get_the_category_list( ', ', 0, $post->ID );

                echo '<div class="col-md-4">';
                echo '<div class="florian-post'.esc_attr($post_class).'"'.florian_add_aos(false).'>';

                if(has_post_thumbnail( $post->ID )) {
                  echo '<div class="florian-post-image-wrapper"><a href="'.esc_url(get_permalink($post->ID)).'"><div class="florian-post-image hover-effect-img" data-style="'.esc_attr($image_bg).'"></div></a></div>';
                }

                // Post details
                echo '<div class="florian-post-details">

                     <div class="florian-post-category">'.wp_kses_post($categories_list).'</div>
                     <div class="florian-post-title"><a href="'.esc_url(get_permalink($post->ID)).'"><h5>'.esc_html($post->post_title).'</h5></a></div>';

                echo '<div class="florian-post-info">
                     <div class="florian-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div>';

                if(get_theme_mod('blog_posts_author', false) == true) {
                    echo '<div class="florian-post-author">'.get_the_author_posts_link().'</div>';
                }

                echo '</div>';
                echo '</div>';
                // END - Post details

                echo '</div>';
                echo '</div>';

            }

            echo '<div class="col-md-12 florian-lastest-posts-button"'.florian_add_aos(false).'><a href="'.esc_url( get_permalink( get_option( 'page_for_posts' ) ) ).'" class="btn alt">'.esc_html__('View all posts', 'florian').'</a></div>';

            wp_reset_postdata();

            echo '</div>';
            echo '</div>';

            echo '</div>';
            echo '</div>';

        }

}
endif;

/**
 * Homepage popular posts slider display
 */
if(!function_exists('florian_popularposts_slider_show')):
function florian_popularposts_slider_show() {

    if(get_theme_mod('popularposts', false) == true) {

        $popular_posts_limit = get_theme_mod('popularposts_limit', 10);

        $popular_posts_category = get_theme_mod('popularposts_category', '');

        $args = array(
            'posts_per_page'   => $popular_posts_limit,
            'order'            => 'DESC',
            'category_name'         => $popular_posts_category,
            'orderby' => 'meta_value',
            'meta_key'         => '_florian_post_views_count',
            'post_type'        => 'post',
            'post_status'      => 'publish',
            'suppress_filters' => 0
        );

        $posts = get_posts( $args );

        $total_posts = sizeof($posts);

        if($total_posts > 0) {

            echo '<div class="florian-popular-post-list-wrapper-bg">';
            echo '<div class="florian-popular-post-list-wrapper clearfix container">';

            echo '<div class="row clearfix">';
            echo '<div class="col-md-12">';
            echo '<div class="florian-popular-post-list-nav">';

            echo '<div class="florian-popular-post-list-nav-next">';
            echo '</div>';
            echo '<div class="florian-popular-post-list-nav-prev">';
            echo '</div>';

            echo '</div>';
            echo '<div class="florian-popular-post-list-content">';
            echo '<div class="florian-popular-post-list-content-inner">';
            echo '<div id="florian-popular-post-list" class="florian-popular-post-list owl-carousel">';

            foreach($posts as $post) {

                setup_postdata($post);

                $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'florian-blog-thumb');

                if(has_post_thumbnail( $post->ID )) {
                    $image_bg ='background-image: url('.$image[0].');';
                    $post_class = '';
                }
                else {
                    $image_bg = '';
                    $post_class = ' florian-post-no-image';
                }

                $categories_list = get_the_category_list( ', ', 0, $post->ID );

                echo '<div class="florian-post'.esc_attr($post_class).'">';

                if(has_post_thumbnail( $post->ID )) {
                  echo '<div class="florian-post-image-wrapper"><a href="'.esc_url(get_permalink($post->ID)).'"><div class="florian-post-image hover-effect-img" data-style="'.esc_attr($image_bg).'"></div></a></div>';
                }

                // Post details
                echo '<div class="florian-post-details">

                     <div class="florian-post-category">'.wp_kses_post($categories_list).'</div>
                     <div class="florian-post-title"><a href="'.esc_url(get_permalink($post->ID)).'"><h5>'.esc_html($post->post_title).'</h5></a></div>';

                echo '<div class="florian-post-info">
                     <div class="florian-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div>';

                if(get_theme_mod('blog_posts_author', false) == true) {
                    echo '<div class="florian-post-author">'.get_the_author_posts_link().'</div>';
                }

                echo '</div>';
                echo '</div>';
                // END - Post details

                echo '</div>';

            }

            wp_reset_postdata();

            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';

            echo '</div>';
            echo '</div>';

            $slider_slides = 4; // Popular posts slides per row

            $slider_autoplay = get_theme_mod('popularposts_autoplay', 5000);

            if($slider_autoplay > 0) {
                $slider_autoplay_bool = 'true';
            } else {
                $slider_autoplay_bool = 'false';
            }

            wp_add_inline_script( 'florian-script', '(function($){
            $(document).ready(function() {

                "use strict";

                var owl = $(".florian-popular-post-list-wrapper .florian-popular-post-list");

                owl.owlCarousel({
                    loop: true,
                    items:'.esc_js($slider_slides).',
                    autoplay:'.esc_js($slider_autoplay_bool).',
                    autowidth: false,
                    autoplayTimeout:'.esc_js($slider_autoplay).',
                    autoplaySpeed: 1000,
                    navSpeed: 1000,
                    dots: false,
                    responsive: {
                        1199:{
                            items:'.esc_js($slider_slides).'
                        },
                        979:{
                            items:3
                        },
                        768:{
                            items:2
                        },
                        479:{
                            items:1
                        },
                        0:{
                            items:1
                        }
                    }
                });

                $(".florian-popular-post-list-wrapper .florian-popular-post-list-nav .florian-popular-post-list-nav-next").on("click", function(){
                    owl.trigger(\'next.owl.carousel\', [1000]);
                });

                $(".florian-popular-post-list-wrapper .florian-popular-post-list-nav .florian-popular-post-list-nav-prev").on("click", function(){
                    owl.trigger(\'prev.owl.carousel\', [1000]);
                });

                AOS.refresh();

            });})(jQuery);');

        }

    }
}
endif;

/**
 * Footer shortcode block display
 */
if(!function_exists('florian_footer_shortcode_show')):
function florian_footer_shortcode_show() {

  if(get_theme_mod('footer_shortcodeblock', false) == true):
  ?>
  <div class="container">
    <div class="footer-shortcode-block">
    <?php echo do_shortcode(get_theme_mod('footer_shortcodeblock_html', '')); ?>
    </div>
  </div>
  <?php
  endif;
}
endif;

/**
 * Subscribe block display
 */
if(!function_exists('florian_subscribe_block_show')):
function florian_subscribe_block_show() {

  if(get_theme_mod('subscribeblock', false) == true):
  ?>
  <div class="container subscribe-block-container"<?php florian_add_aos(); ?>>
    <div class="subscribe-block">
    <?php echo do_shortcode(get_theme_mod('subscribeblock_html', '')); ?>
    </div>
  </div>
  <?php
  endif;
}
endif;

/**
 * Footer Instagram block display
 */
if(!function_exists('florian_footer_instagram_show')):
function florian_footer_instagram_show() {

    // Instagram feed
    if(get_theme_mod('footer_instagram', false) == true) {

        echo '<div class="footer-instagram-wrapper">';
        echo '<div class="footer-instagram-wrapper-title"><h5>'.esc_html__('Instagram', 'florian').'</h5></div>';

        if(get_theme_mod('footer_instagram_title', '') == '') {
            $footer_instagram_title_html = '';
        } else {
            $footer_instagram_title_html = '<div class="footer-instagram-title">'.esc_html(get_theme_mod('footer_instagram_title', '')).'</div>';
        }

        echo wp_kses_post($footer_instagram_title_html);

        echo do_shortcode(get_theme_mod('footer_instagram_shortcode', '[instagram-feed]'));
        echo '</div>';

    }

}
endif;

/**
 * Footer HTML block display
 */
if(!function_exists('florian_footer_htmlblock_show')):
function florian_footer_htmlblock_show() {

  if(get_theme_mod('footer_htmlblock', false) == true) {

    $footer_htmlblock_background = get_theme_mod('footer_htmlblock_background', false);

    $style = 'background-color: '.esc_html($footer_htmlblock_background['background-color']).';';
    $style .= 'color: '.esc_html(get_theme_mod('footer_htmlblock_color_text', '#ffffff')).';';

    if($footer_htmlblock_background['background-image'] !== '') {
      $style .= 'background-image: url('.esc_url($footer_htmlblock_background['background-image']).');';
      $style .= 'background-repeat: '.esc_html($footer_htmlblock_background['background-repeat']).';';
      $style .= 'background-position: '.esc_html($footer_htmlblock_background['background-position']).';';
      $style .= 'background-size: '.esc_html($footer_htmlblock_background['background-size']).';';
      $style .= 'background-attachement: '.esc_html($footer_htmlblock_background['background-size']).';';
    }

    ?>
    <div class="footer-html-block" data-style="<?php echo esc_attr($style); ?>">
    <?php echo do_shortcode(get_theme_mod('footer_htmlblock_html', '')); ?>
    </div>
    <?php

  }
}
endif;

/**
 *  Blog post excerpt display override
 */
if(!function_exists('florian_excerpt_more')):
function florian_excerpt_more( $more ) {
    return '...';
}
endif;
add_filter('excerpt_more', 'florian_excerpt_more');

/**
 *  Blog post read more display override
 */
if(!function_exists('florian_modify_read_more_link')):
function florian_modify_read_more_link() {
    return '<a class="more-link btn alt" href="' . esc_url(get_permalink()) . '">'.esc_html__('View more', 'florian').'</a>';
}
endif;
add_filter( 'the_content_more_link', 'florian_modify_read_more_link' );

/**
 *  Custom BODY CSS classes
 */
if(!function_exists('florian_body_classes')):
function florian_body_classes($classes) {

  // Blog styles
  $blog_style = 1;

  $blog_style_class = Array();

  $blog_style_class[] = 'blog-style-'.$blog_style;

  // Single Post page related classes
  $blog_post_transparent_header = get_theme_mod('blog_post_transparent_header', false);

  // Demo settings
  if ( defined('DEMO_MODE') && isset($_GET['blog_post_transparent_header']) ) {
    if($_GET['blog_post_transparent_header'] == 0) {
      $blog_post_transparent_header = false;
    }
    if($_GET['blog_post_transparent_header'] == 1) {
      $blog_post_transparent_header = true;
    }
  }

  if($blog_post_transparent_header) {
    $classes[] = 'blog-post-transparent-header-enable';
  } else {
    $classes[] = 'blog-post-transparent-header-disable';
  }

  $blog_post_smallwidth = get_theme_mod('blog_post_smallwidth', false);

  // Demo settings
  if ( defined('DEMO_MODE') && isset($_GET['blog_post_smallwidth']) ) {
    if($_GET['blog_post_smallwidth'] == 0) {
      $blog_post_smallwidth = false;
    }
    if($_GET['blog_post_smallwidth'] == 1) {
      $blog_post_smallwidth = true;
    }
  }

  if($blog_post_smallwidth) {
    $classes[] = 'blog-small-page-width';
  }

  // Slider related classes
  $blog_enable_homepage_slider = get_theme_mod('slider_enable', true);

  if($blog_enable_homepage_slider) {

    $classes[] = 'blog-slider-enable';

  } else {
    $classes[] = 'blog-slider-disable';
  }

  if(get_theme_mod('blog_post_dropcaps', true) == true) {
    $classes[] = 'blog-enable-dropcaps';
  }

  if ( get_theme_mod( 'animations_images', true ) == true ) {
    $classes[] = 'blog-enable-images-animations';
  }

  return $classes;
}
endif;
add_filter('body_class', 'florian_body_classes');

/**
 * CMB2 images file list display
 *
 * @param  string  $file_list_meta_key The field meta key. ('wiki_test_file_list')
 * @param  string  $img_size           Size of image to show
 */
if(!function_exists('florian_cmb2_get_images_src')):
function florian_cmb2_get_images_src( $post_id, $file_list_meta_key, $img_size = 'medium' ) {

    // Get the list of files
    $files = get_post_meta( $post_id, $file_list_meta_key, 1 );

    $attachments_image_urls_array = Array();

    foreach ( (array) $files as $attachment_id => $attachment_url ) {

        $current_attach = wp_get_attachment_image_src( $attachment_id, $img_size );

        $attachments_image_urls_array[] = $current_attach[0];

    }

    if($attachments_image_urls_array[0] == '') {
        $attachments_image_urls_array = array();
    }

    return $attachments_image_urls_array;

}
endif;


/**
 * Add on scroll animations to elements
 */
if(!function_exists('florian_add_aos')):
function florian_add_aos($echo = true) {

    $aos_animation = get_theme_mod('aos_animation', '');

    if($aos_animation !== '') {

        $blog_layout = get_theme_mod('blog_layout', 'layout_default');

        if ( defined('DEMO_MODE') && isset($_GET['blog_layout']) ) {
            $blog_layout = $_GET['blog_layout'];
        }

        // Masonry layout does not supported
        if($blog_layout == 'layout_masonry') {
            $data_params = '';
        } else {
            $data_params = ' data-aos="'.esc_attr($aos_animation).'"';
        }

        if($echo) {
            echo wp_kses_post($data_params);
        } else {
            return wp_kses_post($data_params);
        }

    }
}
endif;

/**
 *  Get correct CSS styles for Google fonts variant
 */
if(!function_exists('florian_get_font_style_css')):
function florian_get_font_style_css($variant) {
    $font_style_css = '';

    if(strpos($variant, 'italic')) {
        $font_style_css .= 'font-style: italic;';
        $variant = str_replace('italic', '', $variant);
    }

    if($variant !== 'regular' && $variant !== '') {
        $font_style_css .= 'font-weight: '.$variant.';';
    }

    return $font_style_css;
}
endif;

/**
 * Activate theme first time
 */
if(!function_exists( 'florian_activate_theme' )) {
function florian_activate_theme() {
    if((get_option( 'florian_license_key_status', false ) !== 'activated')) {
        update_option('florian_license_key_status', 'activated');
    }
}
}
//add_action( 'init', 'florian_activate_theme' );

/**
 * Menu Links Customization
 */
class florian_mainmenu_walker extends Walker_Nav_Menu{
      function start_el(&$output, $item, $depth = 0, $args = Array(), $current_object_id = 0 ){
           global $wp_query;
           $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
           $class_names = $value = '';
           $classes = empty( $item->classes ) ? array() : (array) $item->classes;
           $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );

           $add_class = '';

           $post = get_post($item->object_id);

               $class_names = ' class="'.$add_class.' '. esc_attr( $class_names ) . '"';
               $output .= $indent . '<li id="menu-item-'. $item->ID . '"' . $value . $class_names .'>';
               $attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
               $attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
               $attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';

                    $attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';

                if (is_object($args)) {
                    $item_output = $args->before;
                    $item_output .= '<a'. $attributes .'>';
                    $item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID );
                    $item_output .= $args->link_after;
                    if($item->description !== '') {
                        $item_output .= '<span>'.$item->description.'</span>';
                    }

                    $item_output .= '</a>';
                    $item_output .= $args->after;
                    $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );

                }
     }
}
