<?php
/**
 * Theme Options
 **/

// Check that Kirki plugin installed
if ( class_exists( 'Kirki' ) ):

// Load all fonts variants for Google Fonts
function florian_font_add_all_variants() {
    if (class_exists('Kirki_Fonts_Google')) {

        if(get_theme_mod('webfonts_loadallvariants', false)) {
            Kirki_Fonts_Google::$force_load_all_variants = true;
        } else {
            Kirki_Fonts_Google::$force_load_all_variants = false;
        }

    }
}
add_action('init', 'florian_font_add_all_variants');

// Update options cache on customizer save
if(!function_exists('florian_update_options_cache')):
function florian_update_options_cache() {
    $option_name = 'themeoptions_saved_date';

    $new_value = microtime(true) ;

    if ( get_option( $option_name ) !== false ) {

        // The option already exists, so we just update it.
        update_option( $option_name, $new_value );

    } else {

        // The option hasn't been added yet. We'll add it with $autoload set to 'no'.
        $deprecated = null;
        $autoload = 'no';
        add_option( $option_name, $new_value, $deprecated, $autoload );
    }
}
endif;
add_action( 'customize_save_after', 'florian_update_options_cache');

// Change default Customizer options, add new logo option
if(!function_exists('florian_theme_customize_register')):
function florian_theme_customize_register( $wp_customize ) {
    $wp_customize->remove_section( 'colors' );

    $wp_customize->get_section('header_image')->title = esc_html__( 'Logo', 'florian' );

    $wp_customize->get_section('title_tagline')->title = esc_html__( 'Site Title and Favicon', 'florian' );

    $wp_customize->add_setting( 'florian_header_transparent_logo' , array(
         array ( 'default' => '',
                'sanitize_callback' => 'esc_url_raw'
                ),
        'transport'   => 'refresh',
    ) );

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'florian_header_transparent_logo', array(
        'label'    => esc_html__( 'Logo for Transparent Header (Light logo)', 'florian' ),
        'section'  => 'header_image',
        'settings' => 'florian_header_transparent_logo',
    ) ) );

    // Move header image section to theme settings
    $wp_customize->get_section( 'header_image' )->panel = 'theme_settings_panel';
    $wp_customize->get_section( 'header_image' )->priority = 20;
}
endif;
add_action( 'customize_register', 'florian_theme_customize_register' );

// Create theme options
Kirki::add_config( 'florian_theme_options', array(
    'capability'    => 'edit_theme_options',
    'option_type'   => 'theme_mod',
) );

// Create main panel
Kirki::add_panel( 'theme_settings_panel', array(
    'priority'    => 10,
    'title'       => esc_attr__( 'Theme Settings', 'florian' ),
    'description' => esc_attr__( 'Manage theme settings', 'florian' ),
) );

// Theme Activation
if(get_option( 'florian_license_key_status', false ) !== 'activated'):

Kirki::add_section( 'activation', array(
    'title'          => esc_attr__( 'Please register theme first', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'custom',
    'settings'    => 'activation_html',
    'label'       => '',
    'section'     => 'activation',
    'default'     => '<p>'.esc_html('Please register your purchase to get themes updates notifications, import theme demos and get access to premium dedicated support.', 'florian').'</p><a href="themes.php?page=florian_activate_theme" class="button button-primary">'.esc_html('Register theme', 'florian').'</a>',
    'priority'    => 10,
) );

endif; // Theme activated

// SECTION: General
Kirki::add_section( 'general', array(
    'title'          => esc_attr__( 'General', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'animations_css3',
    'label'       => esc_attr__( 'CSS3 animations', 'florian' ),
    'description' => esc_attr__( 'Enable colors and background colors fade effects.', 'florian' ),
    'section'     => 'general',
    'default'     => '1',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'select',
    'settings'    => 'aos_animation',
    'label'       => esc_attr__( 'Animate posts listing on scroll', 'florian' ),
    'section'     => 'general',
    'default'     => '',
    'priority'    => 15,
    'multiple'    => 0,
    'choices'     => array(
        '' => esc_attr__( 'Disable', 'florian' ),
        'fade-up' => esc_attr__( 'Fade up', 'florian' ),
        'fade-down' => esc_attr__( 'Fade down', 'florian' ),
        'zoom-in' => esc_attr__( 'Zoom In', 'florian' ),
    ),
    'description'  => esc_attr__( 'Animate on scroll feature for post blocks in listings. Does not available with Masonry layout.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'animations_images',
    'label'       => esc_attr__( 'Images on hover animations', 'florian' ),
    'description' => esc_attr__( 'Enable mouse hover effects on featured images.', 'florian' ),
    'section'     => 'general',
    'default'     => '1',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'module_mega_menu',
    'label'       => esc_attr__( 'Mega Menu', 'florian' ),
    'description' => esc_attr__( 'Enable Mega Menu module for additional menu options.', 'florian' ),
    'section'     => 'general',
    'default'     => '1',
    'priority'    => 25,
) );

Kirki::add_field( 'theme_config_id', array(
    'type'        => 'number',
    'settings'    => 'module_megamenu_sidebars',
    'label'       => esc_attr__( 'Mega Menu sidebars count', 'florian' ),
    'description'       => esc_attr__( 'Additional sidebars for usage in mega menu items.', 'florian' ),
    'section'     => 'general',
    'default'     => 1,
    'priority'    => 26,
    'choices'     => array(
        'min'  => 0,
        'max'  => 100,
        'step' => 1,
    ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'button_backtotop',
    'label'       => esc_attr__( 'Scroll to top button', 'florian' ),
    'description' => esc_attr__( 'Show scroll to top button after page scroll.', 'florian' ),
    'section'     => 'general',
    'default'     => '1',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'search_position',
    'label'       => esc_attr__( 'Search toggle button position', 'florian' ),
    'section'     => 'general',
    'default'     => 'top_menu',
    'priority'    => 40,
    'choices'     => array(
        'top_menu' => esc_attr__( 'Top menu', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => esc_attr__( 'Change location for search form toggle button.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'background',
    'settings'    => 'body_background',
    'label'       => esc_attr__( 'Body background', 'florian' ),
    'description' => esc_attr__( 'Change your site main background settings.', 'florian' ),
    'section'     => 'general',
    'default'     => array(
        'background-color'      => '#ffffff',
        'background-image'      => '',
        'background-repeat'     => 'repeat',
        'background-position'   => 'center center',
        'background-size'       => 'cover',
        'background-attachment' => 'fixed',
    ),
     'priority'    => 60,
) );
// END SECTION: General

// SECTION: Logo settings (default WordPress modified)
Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'logo_width',
    'label'       => esc_attr__( 'Logo image width (px)', 'florian' ),
    'description' => esc_attr__( 'For example: 150', 'florian' ),
    'section'     => 'header_image',
    'default'     => '135',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'logo_text',
    'label'       => esc_attr__( 'Text logo', 'florian' ),
    'description' => esc_attr__( 'Use text logo instead of image.', 'florian' ),
    'section'     => 'header_image',
    'default'     => '0',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'     => 'text',
    'settings' => 'logo_text_title',
    'label'    => esc_attr__( 'Text logo title', 'florian' ),
    'section'  => 'header_image',
    'default'     => '',
    'description'  => esc_attr__( 'Add your site text logo. HTML tags allowed.', 'florian' ),
    'priority' => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'typography',
    'settings'    => 'logo_text_font',
    'label'       => esc_attr__( 'Text logo font', 'florian' ),
    'section'     => 'header_image',
    'default'     => array(
        'font-family'    => 'Cormorant Garamond',
        'font-size'    => '62px',
        'variant'        => 'regular',
        'color'          => '#000000',
    ),
    'priority'    => 70,
    'output'      => ''
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'logo_position',
    'label'       => esc_attr__( 'Logo position', 'florian' ),
    'section'     => 'header_image',
    'default'     => 'center',
    'priority'    => 80,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'center' => esc_attr__( 'Center', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
    ),
    'description'  => esc_attr__( 'Change logo align and position in header.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'header_tagline',
    'label'       => esc_attr__( 'Header tagline', 'florian' ),
    'description' => esc_attr__( 'Show text tagline in header.', 'florian' ),
    'section'     => 'header_image',
    'default'     => '1',
    'priority'    => 90,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'header_tagline_style',
    'label'       => esc_attr__( 'Header tagline text style', 'florian' ),
    'section'     => 'header_image',
    'default'     => 'regular',
    'priority'    => 100,
    'choices'     => array(
        'regular'   => esc_attr__( 'Regular', 'florian' ),
        'uppercase' => esc_attr__( 'UPPERCASE', 'florian' ),
    ),
    'description'  => esc_attr__( 'Change header tagline text transform style.', 'florian' ),
) );
// END SECTION: Logo settings (default WordPress modified)

// SECTION: Header
Kirki::add_section( 'header', array(
    'title'          => esc_attr__( 'Header', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'header_height',
    'label'       => esc_attr__( 'Header height (px)', 'florian' ),
    'description' => esc_attr__( 'For example: 200', 'florian' ),
    'section'     => 'header',
    'default'     => '200',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'background',
    'settings'    => 'header_background',
    'label'       => esc_attr__( 'Header background', 'florian' ),
    'description' => esc_attr__( 'Change your header background settings.', 'florian' ),
    'section'     => 'header',
    'default'     => array(
        'background-color'      => '#ffffff',
        'background-image'      => '',
        'background-repeat'     => 'no-repeat',
        'background-position'   => 'center top',
        'background-size'       => 'cover',
        'background-attachment' => 'fixed',
    ),
     'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'header_sticky',
    'label'       => esc_attr__( 'Sticky header', 'florian' ),
    'description' => esc_attr__( 'Main Menu fixed to top on scroll.', 'florian' ),
    'section'     => 'header',
    'default'     => '1',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'header_sticky_logo',
    'label'       => esc_attr__( 'Show site logo in sticky header', 'florian' ),
    'description' => '',
    'section'     => 'header',
    'default'     => '0',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'header_banner_1_position',
    'label'       => esc_attr__( 'Header banner 1 position', 'florian' ),
    'section'     => 'header',
    'default'     => 'left',
    'priority'    => 50,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'center' => esc_attr__( 'Center', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'None', 'florian' ),
    ),
    'description'  => esc_attr__( 'You can show banner image or some text in your header. Make sure that you use different positions for logo and your banner (for example logo at the left and banner at the right).', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'header_banner_1_html',
    'label'       => esc_attr__( 'Header banner 1 HTML', 'florian' ),
    'description' => esc_attr__( 'If you selected Header banner position below you can use any HTML here to show your banner or other content in header.', 'florian' ),
    'section'     => 'header',
    'default'     => '',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'header_banner_2_position',
    'label'       => esc_attr__( 'Header banner 2 position', 'florian' ),
    'section'     => 'header',
    'default'     => 'right',
    'priority'    => 60,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'center' => esc_attr__( 'Center', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'None', 'florian' ),
    ),
    'description'  => esc_attr__( 'You can show banner image or some text in your header. Make sure that you use different positions for logo and your banner (for example logo at the left and banner at the right).', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'header_banner_2_html',
    'label'       => esc_attr__( 'Header banner 2 HTML', 'florian' ),
    'description' => esc_attr__( 'If you selected Header banner position below you can use any HTML here to show your banner or other content in header.', 'florian' ),
    'section'     => 'header',
    'default'     => '',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'header_disable',
    'label'       => esc_attr__( 'Disable entire header', 'florian' ),
    'description' => esc_attr__( 'This option will disable ALL header (with menu below header, logo, etc). Useful for minimalistic design with left/right sidebar used to show logo and menu.', 'florian' ),
    'section'     => 'header',
    'default'     => '0',
    'priority'    => 80,
) );
// END SECTION: Header

// SECTION: Top menu
Kirki::add_section( 'topmenu', array(
    'title'          => esc_attr__( 'Top menu', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 40
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'topmenu_style',
    'label'       => esc_attr__( 'Top menu style', 'florian' ),
    'section'     => 'topmenu',
    'default'     => 'menu_black',
    'priority'    => 10,
    'choices'     => array(
        'menu_white'   => esc_attr__( 'Light', 'florian' ),
        'menu_black' => esc_attr__( 'Dark', 'florian' ),

    ),
    'description'  => esc_attr__( 'Change colors styling for top menu.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'topmenu_uppercase',
    'label'       => esc_attr__( 'Top menu text tranform', 'florian' ),
    'section'     => 'topmenu',
    'default'     => 'uppercase',
    'priority'    => 15,
    'choices'     => array(
        'uppercase'   => esc_attr__( 'UPPERCASE', 'florian' ),
        'none' => esc_attr__( 'None', 'florian' ),

    ),
    'description'  => esc_attr__( 'Change text transform for top menu.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'topmenu_socialicons',
    'label'       => esc_attr__( 'Social icons', 'florian' ),
    'description' => esc_attr__( 'Enable social icons in top menu.', 'florian' ),
    'section'     => 'topmenu',
    'default'     => '1',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'topmenu_disable',
    'label'       => esc_attr__( 'Disable top menu', 'florian' ),
    'description' => esc_attr__( 'This option will disable top menu.', 'florian' ),
    'section'     => 'topmenu',
    'default'     => '0',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'dimension',
    'settings'    => 'topmenu_paddings',
    'label'       => esc_attr__( 'Top menu top/bottom paddings (px)', 'florian' ),
    'description' => esc_attr__( 'Adjust this value to change menu height. Default: 10px', 'florian' ),
    'section'     => 'topmenu',
    'default'     => '10px',
    'priority'    => 40,
) );
// END SECTION: Top menu

// SECTION: Main menu
Kirki::add_section( 'mainmenu', array(
    'title'          => esc_attr__( 'Main menu', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 50
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'mainmenu_font_decoration',
    'label'       => esc_attr__( 'Main menu font decoration', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => 'uppercase',
    'priority'    => 10,
    'choices'     => array(
        'uppercase'   => esc_attr__( 'UPPERCASE', 'florian' ),
        'italic' => esc_attr__( 'Italic', 'florian' ),
        'none' => esc_attr__( 'None', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'mainmenu_font_size',
    'label'       => esc_attr__( 'Main menu font size', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => 'normalfont',
    'priority'    => 20,
    'choices'     => array(
        'normalfont'   => esc_attr__( 'Normal', 'florian' ),
        'largefont' => esc_attr__( 'Large', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'mainmenu_font_weight',
    'label'       => esc_attr__( 'Main menu font weight', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => 'regularfont',
    'priority'    => 30,
    'choices'     => array(
        'regularfont'   => esc_attr__( 'Regular', 'florian' ),
        'boldfont' => esc_attr__( 'Bold', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'mainmenu_font_letterspacing',
    'label'       => esc_attr__( 'Main menu font letter spacing', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => 'letterspacing-disable',
    'priority'    => 40,
    'choices'     => array(
        'letterspacing-enable'   => esc_attr__( 'Enable', 'florian' ),
        'letterspacing-disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'mainmenu_arrow_style',
    'label'       => esc_attr__( 'Main menu dropdown arrows', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => 'downarrow',
    'priority'    => 50,
    'choices'     => array(
        'rightarrow'   => esc_attr__( 'Right >', 'florian' ),
        'downarrow' => esc_attr__( 'Down V', 'florian' ),
        'noarrow' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'mainmenu_borders',
    'label'       => esc_attr__( 'Borders in main menu', 'florian' ),
    'description' => esc_attr__( 'Main menu have bordes at top and sides. You can use this option to disable borders and have more clean simple design.', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => '1',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'mainmenu_margin_bottom',
    'label'       => esc_attr__( 'Bottom margin for main menu', 'florian' ),
    'description' => esc_attr__( 'Enable this option if you want to add additional bottom margin for main menu.', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => '1',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'dimension',
    'settings'    => 'mainmenu_paddings',
    'label'       => esc_attr__( 'Main menu top/bottom paddings (px)', 'florian' ),
    'description' => esc_attr__( 'Adjust this value to change menu height. Default: 20px', 'florian' ),
    'section'     => 'mainmenu',
    'default'     => '20px',
    'priority'    => 80,
) );

// END SECTION: Main menu

// SECTION: Footer
Kirki::add_section( 'footer', array(
    'title'          => esc_attr__( 'Footer', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 50
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'footer_style',
    'label'       => esc_attr__( 'Footer style', 'florian' ),
    'section'     => 'footer',
    'default'     => 'footer_white',
    'priority'    => 5,
    'choices'     => array(
        'footer_white'   => esc_attr__( 'Light', 'florian' ),
        'footer_black' => esc_attr__( 'Dark', 'florian' ),

    ),
    'description'  => esc_attr__( 'Change colors styling for footer.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_sidebar_homepage',
    'label'       => esc_attr__( 'Footer sidebar only on homepage', 'florian' ),
    'description' => esc_attr__( 'Disable this option to show footer sidebar on all site pages.', 'florian' ),
    'section'     => 'footer',
    'default'     => '1',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_menu',
    'label'       => esc_attr__( 'Footer menu', 'florian' ),
    'description' => esc_attr__( 'Disable this option to hide footer menu.', 'florian' ),
    'section'     => 'footer',
    'default'     => '1',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_socialicons',
    'label'       => esc_attr__( 'Social icons in footer', 'florian' ),
    'description' => esc_attr__( 'Disable this option to hide footer social icons.', 'florian' ),
    'section'     => 'footer',
    'default'     => '0',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'footer_copyright',
    'label'       => esc_attr__( 'Footer copyright text', 'florian' ),
    'description' => esc_attr__( 'Change your footer copyright text.', 'florian' ),
    'section'     => 'footer',
    'default'     => '',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_shortcodeblock',
    'label'       => esc_attr__( 'Footer shortcode block', 'florian' ),
    'description' => esc_attr__( 'Boxed block with any shortcode from any plugin or HTML in footer.', 'florian' ),
    'section'     => 'footer',
    'default'     => '0',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_shortcodeblock_homepage',
    'label'       => esc_attr__( 'Footer shortcode block only on homepage', 'florian' ),
    'description' => esc_attr__( 'Disable this option to show footer shortcode block on all site pages.', 'florian' ),
    'section'     => 'footer',
    'default'     => '1',
    'priority'    => 55,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'footer_shortcodeblock_html',
    'label'       => esc_attr__( 'Footer shortcode block content', 'florian' ),
    'description' => esc_attr__( 'Add shortcode from any plugin that you want to display here (you can combine it with HTML), for example: <h1>My title</h1><div>[my_shortcode]</div>', 'florian' ),
    'section'     => 'footer',
    'default'     => '',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_htmlblock',
    'label'       => esc_attr__( 'Footer HTML block', 'florian' ),
    'description' => esc_attr__( 'Fullwidth block with any HTML and background image in footer.', 'florian' ),
    'section'     => 'footer',
    'default'     => '0',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_htmlblock_homepage',
    'label'       => esc_attr__( 'Footer HTML block only on homepage', 'florian' ),
    'description' => esc_attr__( 'Disable this option to show footer HTML block on all site pages.', 'florian' ),
    'section'     => 'footer',
    'default'     => '1',
    'priority'    => 75,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'background',
    'settings'    => 'footer_htmlblock_background',
    'label'       => esc_attr__( 'Footer HTML block background', 'florian' ),
    'description' => esc_attr__( 'Upload your footer HTML Block background image (1600x1200px JPG recommended). Remove image to remove background.', 'florian' ),
    'section'     => 'footer',
    'default'     => array(
        'background-color'      => '#ffffff',
        'background-image'      => '',
        'background-repeat'     => 'no-repeat',
        'background-position'   => 'center center',
        'background-size'       => 'cover',
        'background-attachment' => 'fixed',
    ),
     'priority'    => 80,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'footer_htmlblock_color_text',
    'label'       => esc_attr__( 'Footer HTML block text color', 'florian' ),
    'description' => esc_attr__( 'Change text color in footer HTML block', 'florian' ),
    'section'     => 'footer',
    'default'     => '#ffffff',
    'priority'    => 90,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'footer_htmlblock_html',
    'label'       => esc_attr__( 'Footer HTML block content', 'florian' ),
    'description' => esc_attr__( 'You can use any HTML and shortcodes here to display any content in your footer block.', 'florian' ),
    'section'     => 'footer',
    'default'     => '',
    'priority'    => 100,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_instagram',
    'label'       => esc_attr__( 'Instagram block in footer', 'florian' ),
    'description' => esc_attr__( 'Instagram Feed plugin must be activated and configured for this option.', 'florian' ),
    'section'     => 'footer',
    'default'     => '0',
    'priority'    => 110,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'footer_instagram_homepage',
    'label'       => esc_attr__( 'Instagram block only on homepage', 'florian' ),
    'description' => esc_attr__( 'Disable this option if you want to show Instagram block on all site pages.', 'florian' ),
    'section'     => 'footer',
    'default'     => '1',
    'priority'    => 120,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'text',
    'settings'    => 'footer_instagram_title',
    'label'       => esc_attr__( 'Instagram block title', 'florian' ),
    'description' => esc_attr__( 'Leave empty if you don\'t want to show title.', 'florian' ),
    'section'     => 'footer',
    'default'     => '',
    'priority'    => 130,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'text',
    'settings'    => 'footer_instagram_shortcode',
    'label'       => esc_attr__( 'Instagram feed shortcode', 'florian' ),
    'description' => esc_attr__( 'You can change default shortcode here if you use alternative Instagram plugin. Default: [instagram-feed]', 'florian' ),
    'section'     => 'footer',
    'default'     => '[instagram-feed]',
    'priority'    => 140,
) );
// END SECTION: Footer

// SECTION: Blog
Kirki::add_section( 'blog', array(
    'title'          => esc_attr__( 'Blog', 'florian' ),
    'description'    => esc_attr__( 'This settings affect your blog list display (homepage, archive, search).', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 60
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'select',
    'settings'    => 'blog_layout',
    'label'       => esc_html__( 'Blog layout', 'florian' ),
    'section'     => 'blog',
    'default'     => 'layout_default',
    'priority'    => 10,
    'multiple'    => 0,
    'choices'     => array(
        'layout_default'   => esc_attr__( 'Default layout', 'florian' ),
        'layout_2column_design' => esc_attr__( '2 columns', 'florian' ),
        'layout_2column_design_advanced'  => esc_attr__( '2 columns with first big block', 'florian' ),
        'layout_list'   => esc_attr__( 'List with short posts blocks', 'florian' ),
        'layout_list_advanced' => esc_attr__( 'List with short posts and first big block', 'florian' ),
        'layout_masonry'  => esc_attr__( 'Masonry layout', 'florian' ),
        'layout_text'  => esc_attr__( 'Centered text (Minimalistic, No images)', 'florian' ),
    ),
    'description' => esc_attr__( 'This option completely change blog listing layout and posts display.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'select',
    'settings'    => 'blog_posts_excerpt',
    'label'       => esc_html__( 'Blog posts short content display', 'florian' ),
    'section'     => 'blog',
    'default'     => 'content',
    'priority'    => 20,
    'multiple'    => 0,
    'choices'     => array(
        'content'   => esc_attr__('Full content (You will add <!--more--> tag manually)', 'florian'),
        'excerpt' => esc_attr__('Excerpt (Auto crop by words)', 'florian'),
        'none'  => esc_attr__('Disable short content and Continue reading button', 'florian'),
    ),
    'description' => wp_kses_post(__( 'Change short post content display in blog listing.<br/><a href="https://en.support.wordpress.com/more-tag/" target="_blank">Read more</a> about &#x3C;!--more--&#x3E; tag.', 'florian' )),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'blog_posts_excerpt_limit',
    'label'       => esc_attr__( 'Post excerpt length (words)', 'florian' ),
    'description' => esc_attr__( 'Used by WordPress for post shortening. Default: 40', 'florian' ),
    'section'     => 'blog',
    'default'     => '40',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_author',
    'label'       => esc_attr__( 'Author name ("by author")', 'florian' ),
    'description' => '',
    'section'     => 'blog',
    'default'     => '0',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_share',
    'label'       => esc_attr__( 'Share buttons', 'florian' ),
    'description' => '',
    'section'     => 'blog',
    'default'     => '1',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_related',
    'label'       => esc_attr__( 'Related posts', 'florian' ),
    'description' => esc_attr__( 'Display 3 related posts after every post in posts list. Does not available in Masonry layout and 2 column layout.', 'florian' ),
    'section'     => 'blog',
    'default'     => '0',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'select',
    'settings'    => 'blog_posts_related_by',
    'label'       => esc_html__( 'Show related posts by', 'florian' ),
    'section'     => 'blog',
    'default'     => 'tags',
    'priority'    => 70,
    'multiple'    => 0,
    'choices'     => array(
        'tags'   => esc_attr__('Tags', 'florian'),
        'categories' => esc_attr__('Categories', 'florian'),
    ),
    'description' => wp_kses_post(__( 'Related posts can be fetched by the same tags or same categories from original post.', 'florian' )),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_comments',
    'label'       => esc_attr__( 'Comments counter', 'florian' ),
    'description' => esc_attr__( 'This option enable post comments counter display in sliders, theme posts blocks, regular posts blocks.', 'florian' ),
    'section'     => 'blog',
    'default'     => '1',
    'priority'    => 80,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_views',
    'label'       => esc_attr__( 'Views counter', 'florian' ),
    'description' => esc_attr__( 'This option enable post views counter display in sliders, theme posts blocks, regular posts blocks.', 'florian' ),
    'section'     => 'blog',
    'default'     => '0',
    'priority'    => 90,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_posts_disable',
    'label'       => esc_attr__( 'Disable blog posts listing on blog page', 'florian' ),
    'description' => esc_attr__( 'Enable this options if you does not want to show posts on your blog page. You can use this to create minimalistic website (you will have just blog slider, welcome block and other theme blocks on blog homepage.', 'florian' ),
    'section'     => 'blog',
    'default'     => '0',
    'priority'    => 100,
) );

// END SECTION: Blog

// SECTION: Homepage
Kirki::add_section( 'homepage', array(
    'title'          => esc_attr__( 'Home: Static page', 'florian' ),
    'description'    => esc_attr__( 'This settings affect your static homepage display (if you use static homepage template instead of blog page homepage).', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 60
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'homepage_latest_posts_limit',
    'label'       => esc_attr__( 'Latest posts limit', 'florian' ),
    'description' => esc_attr__( 'How many latest posts you want to display on static homepage. Note - if you want to change limit for your regular BLOG page you can do this in Settings > Reading in WordPress dashboard.', 'florian' ),
    'section'     => 'homepage',
    'default'     => '6',
    'priority'    => 10,
) );
// END SECTION: Homepage

// SECTION: Blog Slider
Kirki::add_section( 'slider', array(
    'title'          => esc_attr__( 'Home: Blog slider', 'florian' ),
    'description'    => esc_attr__( 'Settings for homepage slider located below header.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 70
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'slider_enable',
    'label'       => esc_attr__( 'Blog Slider', 'florian' ),
    'description' => esc_attr__( 'Enable posts slider in blog page header.', 'florian' ),
    'section'     => 'slider',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'slider_custom',
    'label'       => esc_attr__( 'Custom slider', 'florian' ),
    'description' => esc_attr__( 'You can use third party slider plugins instead of theme slider. IMPORTANT: All theme slider options BELOW will NOT WORK if you enabled custom slider, use your slider plugin settings instead. You must specify your third party slider shortcode below.', 'florian' ),
    'section'     => 'slider',
    'default'     => '0',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'text',
    'settings'    => 'slider_custom_shortcode',
    'label'       => esc_attr__( 'Custom slider shortcode', 'florian' ),
    'description' => esc_attr__( 'Add your custom slider shortcode here (ignore this option if you use theme slider). For example: [your-slider]', 'florian' ),
    'section'     => 'slider',
    'default'     => '',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'slider_width',
    'label'       => esc_attr__( 'Slider width', 'florian' ),
    'description'  => '',
    'section'     => 'slider',
    'default'     => 'boxed',
    'priority'    => 50,
    'choices'     => array(
        'fullwidth'   => esc_attr__( 'Fullwidth', 'florian' ),
        'boxed' => esc_attr__( 'Boxed', 'florian' ),
    ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'slider',
    'settings'    => 'slider_height',
    'label'       => esc_attr__( 'Slider image height (px)', 'florian' ),
    'description' => esc_attr__( 'Drag to change value. Default: 500', 'florian' ),
    'section'     => 'slider',
    'default'     => 500,
    'choices'     => array(
        'min'  => '380',
        'max'  => '800',
        'step' => '5',
    ),
    'section'     => 'slider',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'slider_posts_type',
    'label'       => esc_attr__( 'Slider posts', 'florian' ),
    'section'     => 'slider',
    'default'     => 'featured',
    'priority'    => 70,
    'choices'     => array(
        'featured'   => esc_attr__( 'Featured', 'florian' ),
        'latest' => esc_attr__( 'Latest', 'florian' ),
    ),
    'description'  => esc_attr__( 'Featured - you can assign posts to slider in post edit screen at the bottom settings box. Latest - your latest posts by date.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'slider_limit',
    'label'       => esc_attr__( 'Slider posts limit', 'florian' ),
    'description' => esc_attr__( 'Limit posts in slider. For example: 10', 'florian' ),
    'section'     => 'slider',
    'default'     => '30',
    'priority'    => 80,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'slider_autoplay',
    'label'       => esc_attr__( 'Slider autoplay (sec)', 'florian' ),
    'description' => '',
    'section'     => 'slider',
    'default'     => '0',
    'priority'    => 110,
    'choices'     => array(
        '0'   => esc_attr__( 'Disable', 'florian' ),
        '10000' => '10',
        '5000' => '5',
        '3000' => '3',
        '2000' => '2',
        '1000' => '1',
    ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'slider_arrows',
    'label'       => esc_attr__( 'Navigation arrows', 'florian' ),
    'description' => '',
    'section'     => 'slider',
    'default'     => '1',
    'priority'    => 120,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'slider_text_color',
    'label'       => esc_attr__( 'Slider text color', 'florian' ),
    'description'  => '',
    'section'     => 'slider',
    'default'     => 'black',
    'priority'    => 130,
    'choices'     => array(
        'black'   => esc_attr__( 'Black', 'florian' ),
        'white' => esc_attr__( 'White', 'florian' ),
    ),
) );

// END SECTION: Blog Slider

// SECTION: Subscribe block
Kirki::add_section( 'subscribeblock', array(
    'title'          => esc_attr__( 'Home: Subscribe block', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 75
) );
Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'subscribeblock',
    'label'       => esc_attr__( 'Subscribe block', 'florian' ),
    'description' => esc_attr__( 'Boxed block with any shortcode from any plugin or HTML below slider on homepage. Can be used with subscription form from Mailchimp WP plugin. Also can be enabled on single post page.', 'florian' ),
    'section'     => 'subscribeblock',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'subscribeblock_html',
    'label'       => esc_attr__( 'Subscribe block content', 'florian' ),
    'description' => esc_attr__( 'Add shortcode from any plugin that you want to display here (you can combine it with HTML), for example: <h5>My title</h5><div>[my_shortcode]</div>', 'florian' ),
    'section'     => 'subscribeblock',
    'default'     => '',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'custom',
    'settings'    => 'subscribeblock_example',
    'label'       => '',
    'section'     => 'subscribeblock',
    'default'     => 'Example subscribe block HTML code for Mailchimp WP plugin (change form id):<br><br><i>&#x3C;div class=&#x22;row&#x22;&#x3E;&#x3C;div class=&#x22;col-md-4&#x22;&#x3E;&#x3C;h5&#x3E;Join our newsletter&#x3C;/h5&#x3E;&#x3C;/div&#x3E;&#x3C;div class=&#x22;col-md-4&#x22;&#x3E;&#x3C;p&#x3E;Enter your email and we\&#x27;ll keep you posted with news and updates!&#x3C;/p&#x3E;
&#x3C;/div&#x3E;&#x3C;div class=&#x22;col-md-4&#x22;&#x3E;[mc4wp_form id=&#x22;1&#x22;]&#x3C;/div&#x3E;&#x3C;/div&#x3E;</i><br><br>Please check <a href="'.esc_url('http://magniumthemes.com/go/florian-docs/').'" target="_blank">theme documentation</a> for more information about this option configuration.',
    'priority'    => 30,
) );

// END SECTION: Subscribe block

// SECTION: Welcome block
Kirki::add_section( 'welcomeblock', array(
    'title'          => esc_attr__( 'Home: Welcome block', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 80
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'welcomeblock',
    'label'       => esc_attr__( 'Welcome block on homepage', 'florian' ),
    'description' => esc_attr__( 'This block located below blog slider on homepage. You can use any HTML to display any content in your welcome block with predefined theme layouts and styles.', 'florian' ),
    'section'     => 'welcomeblock',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'welcomeblock_html',
    'label'       => esc_attr__( 'Welcome block HTML', 'florian' ),
    'description' => esc_attr__( 'You can use any HTML and shortcodes here. Switch editor to "Text" mode to avoid issues with WordPress auto tags replace in your HTML code.', 'florian' ),
    'section'     => 'welcomeblock',
    'default'     => '',
    'priority'    => 20,
) );
// END SECTION: Welcome block

// SECTION: Featured categories
Kirki::add_section( 'featured_categories', array(
    'title'          => esc_attr__( 'Home: Featured categories', 'florian' ),
    'description'    => esc_attr__( 'Homepage block with selected categories boxes.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 82
) );

$wp_categories = Kirki_Helper::get_terms( 'category' );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'multicheck',
    'settings'    => 'featured_categories',
    'label'       => esc_attr__( 'Featured categories', 'florian' ),
    'description' => esc_attr__( 'Select featured categories for display on homepage. You need to upload categories header background images in every category settings page.', 'florian' ),
    'section'     => 'featured_categories',
    'default'     => '',
    'priority'    => 10,
    'choices'     => $wp_categories,
) );

// END SECTION: Featured categories

// SECTION: About block
Kirki::add_section( 'aboutblock', array(
    'title'          => esc_attr__( 'Home: About block', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 85
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'aboutblock',
    'label'       => esc_attr__( 'About block on homepage', 'florian' ),
    'description' => esc_attr__( 'This block located below blog slider on homepage. You can use any HTML to display any content in your about block with custom uploaded image.', 'florian' ),
    'section'     => 'aboutblock',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'aboutblock_html',
    'label'       => esc_attr__( 'About block HTML', 'florian' ),
    'description' => esc_attr__( 'You can use any HTML and shortcodes here. Switch editor to "Text" mode to avoid issues with WordPress auto tags replace in your HTML code.', 'florian' ),
    'section'     => 'aboutblock',
    'default'     => '',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'image',
    'settings'    => 'aboutblock_image',
    'label'       => esc_attr__( 'About block image', 'florian' ),
    'description' => esc_attr__( 'JPG image, 1000x1000px size recommended.', 'florian' ),
    'section'     => 'aboutblock',
    'default'     => '',
    'priority'    => 30,
    'choices'     => array(
        'save_as' => 'id',
    ),
) );
// END SECTION: About block

// SECTION: Popular posts carousel
Kirki::add_section( 'popularposts', array(
    'title'          => esc_attr__( 'Home: Popular posts carousel', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 90
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'popularposts',
    'label'       => esc_attr__( 'Popular posts above header', 'florian' ),
    'description' => esc_attr__( 'Carousel with popular posts (by views) above your header on homepage.', 'florian' ),
    'section'     => 'popularposts',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'popularposts_homepage',
    'label'       => esc_attr__( 'Popular posts only on homepage', 'florian' ),
    'description' => esc_attr__( 'Disable this option if you want to show Popular Posts carousel on all site pages.', 'florian' ),
    'section'     => 'popularposts',
    'default'     => '1',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'number',
    'settings'    => 'popularposts_limit',
    'label'       => esc_attr__( 'Popular posts limit', 'florian' ),
    'description' => esc_attr__( 'For example: 10', 'florian' ),
    'section'     => 'popularposts',
    'default'     => '10',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'text',
    'settings'    => 'popularposts_category',
    'label'       => esc_attr__( 'Popular posts category slug', 'florian' ),
    'description' => esc_attr__( 'If you want to show popular posts only from some category specify it\'s SLUG here (You can create special category like "Popular" and assing posts to it if you want to show only selected posts). You can see/set category SLUG when you edit category. Leave empty to show popular posts from all categories.', 'florian' ),
    'section'     => 'popularposts',
    'default'     => '',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'popularposts_autoplay',
    'label'       => esc_attr__( 'Carousel autoplay (sec)', 'florian' ),
    'description' => '',
    'section'     => 'popularposts',
    'default'     => '5000',
    'priority'    => 60,
    'choices'     => array(
        '0'   => esc_attr__( 'Disable', 'florian' ),
        '10000' => '10',
        '5000' => '5',
        '3000' => '3',
        '2000' => '2',
        '1000' => '1',
    ),
) );
// END SECTION: Popular posts carousel

// SECTION: Editor's picks posts block
Kirki::add_section( 'editorspicks', array(
    'title'          => esc_attr__( 'Home: Editor\'s picks posts block', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 90
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'editorspicks',
    'label'       => esc_attr__( 'Editor\'s picks on homepage', 'florian' ),
    'description' => esc_attr__( 'Special block with one from handpicked posts in footer on homepage.', 'florian' ),
    'section'     => 'editorspicks',
    'default'     => '0',
    'priority'    => 10,
) );

// END SECTION: Editor's picks posts block

// SECTION: Blog Single Post
Kirki::add_section( 'blog_post', array(
    'title'          => esc_attr__( 'Blog single post', 'florian' ),
    'description'    => esc_attr__( 'This settings affect your blog single post display.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 100
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_transparent_header',
    'label'       => esc_attr__( 'Transparent header', 'florian' ),
    'description' => esc_attr__( 'This feature make your header transparent and will show it above post/page header image. You need to upload light logo version to use this feature and assign header image for posts/pages where you want to see this feature.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_smallwidth',
    'label'       => esc_attr__( 'Small content width', 'florian' ),
    'description' => esc_attr__( 'This option add left/right margins on all pages and posts without sidebars to make your content width smaller.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_author',
    'label'       => esc_attr__( 'Author details', 'florian' ),
    'description' => esc_attr__( 'Show post author details with avatar after post content. You need to fill your post author biography details and social links in "Users" section in WordPress.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_info_bottom',
    'label'       => esc_attr__( 'Bottom post info', 'florian' ),
    'description' => esc_attr__( 'Show post info box with comments count, views and post share buttons after post content.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_info_header',
    'label'       => esc_attr__( 'Header post info', 'florian' ),
    'description' => esc_attr__( 'Show post info with post share buttons below post title in header.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_featured_image',
    'label'       => esc_attr__( 'Featured image', 'florian' ),
    'description' => esc_attr__( 'Disable to hide post featured image on single post page.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_dropcaps',
    'label'       => esc_attr__( 'Drop caps (first big letter)', 'florian' ),
    'description' => '',
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 80,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_reading_progress',
    'label'       => esc_attr__( 'Reading progress bar', 'florian' ),
    'description' => esc_attr__( 'Show reading progress bar in fixed header.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 85,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_share',
    'label'       => esc_attr__( 'Share buttons', 'florian' ),
    'description' => '',
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 90,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_related',
    'label'       => esc_attr__( 'Related posts', 'florian' ),
    'description' => '',
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 100,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_comments',
    'label'       => esc_attr__( 'Comments counter', 'florian' ),
    'description' => '',
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 110,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_views',
    'label'       => esc_attr__( 'Views counter', 'florian' ),
    'description' => '',
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 120,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_nav',
    'label'       => esc_attr__( 'Navigation links', 'florian' ),
    'description' => esc_attr__( 'Previous/next posts navigation links below post content.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 130,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_subscribe',
    'label'       => esc_attr__( 'Subscribe block', 'florian' ),
    'description' => esc_attr__( 'Show subscription block below related posts. Check theme documentation about subscription block configuration.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 135,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_tags',
    'label'       => esc_attr__( 'Tags', 'florian' ),
    'description' => esc_attr__( 'Disable to hide post tags on single post page.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '1',
    'priority'    => 140,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'blog_post_worthreading',
    'label'       => esc_attr__( 'Worth reading post', 'florian' ),
    'description' => esc_attr__( 'Show one from selected suggested posts in fly-up fixed block in right bottom corner. Posts can be selected in your Post settings.', 'florian' ),
    'section'     => 'blog_post',
    'default'     => '0',
    'priority'    => 150,
) );
// END SECTION: Blog Single Post

// SECTION: Sidebars
Kirki::add_section( 'sidebars', array(
    'title'          => esc_attr__( 'Sidebars', 'florian' ),
    'description'    => esc_attr__( 'Choose your sidebar positions for different WordPress pages.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 110
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_blog',
    'label'       => esc_attr__( 'Blog listing', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'right',
    'priority'    => 10,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_post',
    'label'       => esc_attr__( 'Single Post', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'disable',
    'priority'    => 20,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => esc_attr__( 'You can override sidebar position for every post in post settings.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_page',
    'label'       => esc_attr__( 'Single page', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'disable',
    'priority'    => 30,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => esc_attr__( 'You can override sidebar position for every page in page settings.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_archive',
    'label'       => esc_attr__( 'Archive', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'right',
    'priority'    => 40,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_search',
    'label'       => esc_attr__( 'Search', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'right',
    'priority'    => 50,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_woocommerce',
    'label'       => esc_attr__( 'WooCommerce pages', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'disable',
    'priority'    => 60,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'radio-buttonset',
    'settings'    => 'sidebar_woocommerce_product',
    'label'       => esc_attr__( 'WooCommerce product page', 'florian' ),
    'section'     => 'sidebars',
    'default'     => 'disable',
    'priority'    => 70,
    'choices'     => array(
        'left'   => esc_attr__( 'Left', 'florian' ),
        'right' => esc_attr__( 'Right', 'florian' ),
        'disable' => esc_attr__( 'Disable', 'florian' ),
    ),
    'description'  => '',
) );
// END SECTION: Sidebars

// SECTION: Social icons
Kirki::add_section( 'social', array(
    'title'          => esc_attr__( 'Social icons', 'florian' ),
    'description'    => esc_attr__( 'Add your social icons and urls. Social icons can be used in several site areas, sidebars widgets and shortcodes.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 120
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'repeater',
    'label'       => esc_attr__( 'Social icons (your profiles)', 'florian' ),
    'section'     => 'social',
    'priority'    => 10,
    'row_label' => array(
        'type' => 'field',
        'value' => esc_attr__('Social icon', 'florian' ),
        'field' => 'social_type',
    ),
    'button_label' => esc_attr__('Add social icon', 'florian' ),
    'settings'     => 'social_icons',
    'default'      => '',
    'fields' => array(
        'social_type' => array(
            'type'        => 'select',
            'label'       => esc_attr__( 'Social web', 'florian' ),
            'description' => '',
            'choices'     => florian_social_services_list(),
            'default'     => 'facebook',
        ),
        'social_url' => array(
            'type'        => 'text',
            'label'       => esc_attr__( 'Your profile url (including https://)', 'florian' ),
            'description' => '',
            'default'     => '',
        ),
    )
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_facebook',
    'label'       => esc_attr__( 'Social share - Facebook', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_twitter',
    'label'       => esc_attr__( 'Social share - Twitter', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_google',
    'label'       => esc_attr__( 'Social share - Google+', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_linkedin',
    'label'       => esc_attr__( 'Social share - Linkedin', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_pinterest',
    'label'       => esc_attr__( 'Social share - Pinterest', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'social_share_vk',
    'label'       => esc_attr__( 'Social share - VKontakte', 'florian' ),
    'description' => esc_attr__( 'Enable/Disable social share button for blog posts.', 'florian' ),
    'section'     => 'social',
    'default'     => '1',
    'priority'    => 80,
) );

// END SECTION: Social icons

// SECTION: Fonts
Kirki::add_section( 'fonts', array(
    'title'          => esc_attr__( 'Fonts', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 130,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'typography',
    'settings'    => 'headers_font',
    'label'       => esc_attr__( 'Headers font', 'florian' ),
    'section'     => 'fonts',
    'default'     => array(
        'font-family'    => 'Cormorant Garamond',
        'variant'        => 'regular',
    ),
    'description' => esc_attr__( 'Font used in headers (H1-H6 tags).', 'florian' ),
    'priority'    => 10,
    'output'      => ''
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'typography',
    'settings'    => 'body_font',
    'label'       => esc_attr__( 'Body font', 'florian' ),
    'section'     => 'fonts',
    'default'     => array(
        'font-family'    => 'Noto Serif',
        'variant'        => 'regular',
        'font-size'      => '15px',
    ),
    'description' => esc_attr__( 'Font used in text elements.', 'florian' ),
    'priority'    => 20,
    'output'      => ''
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'typography',
    'settings'    => 'additional_font',
    'label'       => esc_attr__( 'Additional font', 'florian' ),
    'section'     => 'fonts',
    'default'     => array(
        'font-family'    => 'Karla',
        'variant'        => 'regular',
    ),
    'description' => esc_attr__( 'Decorative font used in buttons, menus and some other elements.', 'florian' ),
    'priority'    => 30,
    'output'      => ''
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'webfonts_loadallvariants',
    'label'       => esc_attr__( 'Load all Google Fonts variants and subsets', 'florian' ),
    'description' => esc_attr__( 'Enable to load all available variants and subsets for fonts that you selected.', 'florian' ),
    'section'     => 'fonts',
    'default'     => '0',
    'priority'    => 40,
) );
// END SECTION: Fonts

// SECTION: Colors
Kirki::add_section( 'colors', array(
    'title'          => esc_attr__( 'Colors', 'florian' ),
    'description'    => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 140,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'select',
    'settings'    => 'color_skin',
    'label'       => esc_html__( 'Predefined color skin', 'florian' ),
    'section'     => 'colors',
    'default'     => 'none',
    'priority'    => 10,
    'multiple'    => 0,
    'choices'     => array(
        'none'   => esc_attr__( 'Use colors specified below', 'florian' ),
        'default' => esc_attr__( 'Default', 'florian' ),
        'black' => esc_attr__('Black', 'florian'),
        'grey' => esc_attr__('Grey', 'florian'),
        'lightblue' => esc_attr__('Light blue', 'florian'),
        'blue' => esc_attr__('Blue', 'florian'),
        'red' => esc_attr__('Red', 'florian'),
        'green' => esc_attr__('Green', 'florian'),
        'orange' => esc_attr__('Orange', 'florian'),
        'redorange' => esc_attr__('RedOrange', 'florian'),
        'brown' => esc_attr__('Brown', 'florian'),
    ),
    'description' => esc_attr__( 'Select one of predefined skins or use your own colors. If you selected any predefined skins your colors below will NOT be applied.', 'florian' ),
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_main',
    'label'       => esc_attr__( 'Main theme color', 'florian' ),
    'description' => esc_attr__( 'Used in multiple theme areas (links, buttons, etc).', 'florian' ),
    'section'     => 'colors',
    'default'     => '#bd9e81',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_button_hover',
    'label'       => esc_attr__( 'Buttons background color', 'florian' ),
    'description' => esc_attr__( 'Used in alternative buttons, that does not use main theme color.', 'florian' ),
    'section'     => 'colors',
    'default'     => '#000000',
    'priority'    => 25,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_text',
    'label'       => esc_attr__( 'Body text color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#333333',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_topmenu_bg',
    'label'       => esc_attr__( 'Top menu background color (light menu)', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#FFFFFF',
    'priority'    => 32,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_topmenu_dark_bg',
    'label'       => esc_attr__( 'Top menu background color (dark menu)', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#000000',
    'priority'    => 34,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_bg',
    'label'       => esc_attr__( 'Mainmenu background color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#FFFFFF',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_link',
    'label'       => esc_attr__( 'Mainmenu link color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#000000',
    'priority'    => 41,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_link_hover',
    'label'       => esc_attr__( 'Mainmenu link hover color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#bd9e81',
    'priority'    => 42,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_submenu_bg',
    'label'       => esc_attr__( 'Mainmenu submenu background color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#ffffff',
    'priority'    => 43,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_submenu_link',
    'label'       => esc_attr__( 'Mainmenu submenu link color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#000000',
    'priority'    => 44,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_mainmenu_submenu_link_hover',
    'label'       => esc_attr__( 'Mainmenu submenu link hover color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#bd9e81',
    'priority'    => 45,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_footer_bg',
    'label'       => esc_attr__( 'Footer background color (light footer)', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#FFFFFF',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_footer_dark_bg',
    'label'       => esc_attr__( 'Footer background color (dark footer)', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#000000',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_footer_sidebar_bg',
    'label'       => esc_attr__( 'Footer sidebar background color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#3C3D41',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'color',
    'settings'    => 'color_slider_bg',
    'label'       => esc_attr__( 'Blog slider background color', 'florian' ),
    'description' => '',
    'section'     => 'colors',
    'default'     => '#F8F8F8',
    'priority'    => 80,
) );

// END SECTION: Colors

// SECTION: Ads management
Kirki::add_section( 'banners', array(
    'title'          => esc_attr__( 'Banners management', 'florian' ),
    'description' => esc_attr__( 'You can add any HTML, JavaScript and WordPress shortcodes in this blocks content to show your advertisement. Switch to Text editor mode to add HTML/JavaScript code.', 'florian' ),
    'panel'          => 'theme_settings_panel',
    'priority'       => 150,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_header',
    'label'       => esc_attr__( 'Header banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 10,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_header_content',
    'label'       => esc_attr__( 'Header banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed in site header below top menu.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 20,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_below_header',
    'label'       => esc_attr__( 'Below header banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 30,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_below_header_content',
    'label'       => esc_attr__( 'Below header banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed below site header.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 40,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_above_footer',
    'label'       => esc_attr__( 'Above footer banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 50,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_above_footer_content',
    'label'       => esc_attr__( 'Above footer banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed above site footer.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 60,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_footer',
    'label'       => esc_attr__( 'Footer banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 70,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_footer_content',
    'label'       => esc_attr__( 'Footer banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed in site footer.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 80,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_below_homepage_popular_posts',
    'label'       => esc_attr__( 'Below popular posts banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 90,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_below_homepage_popular_posts_content',
    'label'       => esc_attr__( 'Below popular posts banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed on homepage below popular posts carousel.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 100,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_posts_loop_middle',
    'label'       => esc_attr__( 'Posts list middle banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 110,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_posts_loop_middle_content',
    'label'       => esc_attr__( 'Posts list middle banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed at the middle between posts on all posts listing pages (Homepage, Archives, Search, etc). This banner does not available in Masonry and Two column blog layouts.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 120,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_posts_loop_bottom',
    'label'       => esc_attr__( 'Posts list bottom banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 130,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_posts_loop_bottom_content',
    'label'       => esc_attr__( 'Posts list bottom banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed at the bottom after all posts on posts listing pages (Homepage, Archives, Search, etc).', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 140,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_single_post_top',
    'label'       => esc_attr__( 'Single post top banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 150,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_single_post_top_content',
    'label'       => esc_attr__( 'Single post top banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed on single blog post page between post content and featured image.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 160,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_single_post_bottom',
    'label'       => esc_attr__( 'Single post bottom banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 170,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_single_post_bottom_content',
    'label'       => esc_attr__( 'Single post bottom banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed on single blog post page after post content.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 180,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'toggle',
    'settings'    => 'banner_404',
    'label'       => esc_attr__( '404 page banner', 'florian' ),
    'description' => '',
    'section'     => 'banners',
    'default'     => '0',
    'priority'    => 190,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'editor',
    'settings'     => 'banner_404_content',
    'label'       => esc_attr__( '404 page banner HTML', 'florian' ),
    'description' => esc_attr__( 'Displayed on 404 not found page.', 'florian' ),
    'section'     => 'banners',
    'default'     => '',
    'priority'    => 200,
) );

// SECTION: Support and updates
Kirki::add_section( 'about', array(
    'title'          => esc_attr__( 'Documentation & Support', 'florian' ),
    'description' => '',
    'panel'          => 'theme_settings_panel',
    'priority'       => 150,
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'custom',
    'settings'    => 'about_support',
    'label'       => '',
    'section'     => 'about',
    'default'     => '<div class="documentation-icon"><a href="http://magniumthemes.com/" target="_blank"><img src="'.get_template_directory_uri().'/img/developer-icon.png" alt="MagniumThemes"/></a></div><p>We recommend you to read <a href="http://magniumthemes.com/go/florian-docs/" target="_blank">Theme Documentation</a> before you will start using our theme to building your website. It covers all steps for site configuration, demo content import, theme features usage and more.</p>
<p>If you have face any problems with our theme feel free to use our <a href="http://support.magniumthemes.com/" target="_blank">Support System</a> to contact us and get help for free.</p>
<a class="button button-primary" href="http://magniumthemes.com/go/florian-docs/" target="_blank">Documentation</a> <a class="button button-primary" href="http://support.magniumthemes.com/" target="_blank">Support System</a>
<p><strong>Theme developed by <a href="http://magniumthemes.com/" target="_blank">MagniumThemes</a>.</strong><br/>All rights reserved.</p>
<a class="button button-primary" href="http://magniumthemes.com/themes/" target="_blank">Our WordPress themes</a>',
    'priority'    => 10,
) );
// END SECTION: Support and updates

// SECTION: Additional JavaScript
Kirki::add_section( 'customjs', array(
    'title'          => esc_attr__( 'Additional JavaScript', 'florian' ),
    'description'    => '',
    'panel'          => '',
    'priority'       => 220
) );

Kirki::add_field( 'florian_theme_options', array(
    'type'        => 'code',
    'settings'    => 'custom_js_code',
    'label'       => esc_attr__( 'Custom JavaScript code', 'florian' ),
    'description' => esc_attr__( 'This code will run in header, do not add &#x3C;script&#x3E;...&#x3C;/script&#x3E; tags here, this tags will be added automatically. You can use JQuery code here.', 'florian' ),
    'section'     => 'customjs',
    'default'     => '',
    'choices'     => array(
        'language' => 'js',
    ),
    'priority'    => 10,
) );

// END SECTION: Additional JavaScript
else:
    add_action( 'admin_notices', 'florian_kirki_warning' );
endif;

/*
*   Kirki not installed warning display
*/
if (!function_exists('florian_kirki_warning')) :
function florian_kirki_warning() {

    $message_html = '<div class="notice notice-error"><p><strong>WARNING:</strong> Please <a href="'.esc_url( admin_url( 'themes.php?page=install-required-plugins&plugin_status=install' ) ).'">install and activate Florian Theme Settings (Kirki Toolkit)</a> required plugin, <strong>theme settings will not work without it</strong>.</p></div>';

    echo wp_kses_post($message_html);

}
endif;

