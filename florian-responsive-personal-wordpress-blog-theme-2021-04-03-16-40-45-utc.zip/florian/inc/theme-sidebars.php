<?php
/* Widgets */
if(!function_exists('florian_sidebars_init')):
function florian_sidebars_init() {

    register_sidebar(
      array(
        'name' => esc_html__( 'Default Blog sidebar', 'florian' ),
        'id' => 'main-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Main Blog page, Archives, Search.', 'florian' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Single Blog Post sidebar', 'florian' ),
        'id' => 'post-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Single Blog Post.', 'florian' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Page sidebar', 'florian' ),
        'id' => 'page-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column on: Page.', 'florian' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'WooCommerce sidebar', 'florian' ),
        'id' => 'woocommerce-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in the left or right site column for woocommerce pages.', 'florian' )
      )
    );

    register_sidebar(
      array(
        'name' => esc_html__( 'Footer sidebar', 'florian' ),
        'id' => 'footer-sidebar',
        'description' => esc_html__( 'Widgets in this area will be shown in site footer in 3 columns.', 'florian' )
      )
    );

    register_sidebar(
      array(
        'name' => __( 'Footer Dark sidebar', 'florian' ),
        'id' => 'footer-sidebar-2',
        'description' => __( 'Widgets in this area will be shown in site footer in 4 column after Footer sidebar #1.', 'florian' )
      )
    );

    // Mega Menu sidebars
    if(get_theme_mod('module_megamenu_sidebars', 1) > 0) {
        for ($i = 1; $i <= get_theme_mod('module_megamenu_sidebars', 1); $i++) {
            register_sidebar(
              array(
                'name' => esc_html__( 'Mega Menu sidebar #', 'florian' ).$i,
                'id' => 'megamenu_sidebar_'.$i,
                'description' => esc_html__( 'You can use this sidebar to display widgets inside megamenu items in menus.', 'florian' )
              )
            );
        }
    }

}
endif;
add_action( 'widgets_init', 'florian_sidebars_init' );

?>
