<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Florian
 */

get_header();

$blog_sidebarposition = get_theme_mod('sidebar_blog', 'right');

// Demo settings
if ( defined('DEMO_MODE') && isset($_GET['blog_sidebar_position']) ) {
  $blog_sidebarposition = $_GET['blog_sidebar_position'];
}

if(is_active_sidebar( 'main-sidebar' ) && ($blog_sidebarposition !== 'disable') ) {
	$span_class = 'col-md-9';
}
else {
	$span_class = 'col-md-12';
}

// Blog layout
$blog_layout = get_theme_mod('blog_layout', 'layout_default');

if ( defined('DEMO_MODE') && isset($_GET['blog_layout']) ) {
    $blog_layout = $_GET['blog_layout'];
}

if($blog_layout == 'layout_masonry') {

	wp_enqueue_script('masonry');
	wp_add_inline_script( 'masonry', '(function($){
$(document).ready(function() {

	"use strict";

	var $container = $(".blog-masonry-layout");
	$container.imagesLoaded(function(){
	  $container.masonry({
	    itemSelector : ".blog-masonry-layout .blog-post"
	  });
	});

	AOS.refresh();

});})(jQuery);');

	$blog_enable_masonry_design = true;
	$blog_masonry_class = ' blog-masonry-layout';
} else {
	$blog_enable_masonry_design = false;
	$blog_masonry_class = '';
}

$temp_query = $wp_query;

?>

<div class="content-block">

	<?php if(is_front_page()): ?>

		<?php florian_blog_modern_slider_show(); ?>

		<?php florian_subscribe_block_show(); ?>

		<?php florian_about_block_show(); ?>

		<?php florian_welcome_block_show(); ?>

		<?php florian_featured_categories_block_show(); ?>

	<?php endif; ?>

	<?php
	// Disable blog posts loop
	if(get_theme_mod('blog_posts_disable', false) == false):
	?>
	<div class="page-container container">
		<div class="row">
			<?php if ( is_active_sidebar( 'main-sidebar' ) && ( $blog_sidebarposition == 'left')) : ?>
			<div class="col-md-3 main-sidebar sidebar">
			<ul id="main-sidebar">
			  <?php dynamic_sidebar( 'main-sidebar' ); ?>
			</ul>
			</div>
			<?php endif; ?>

			<div class="<?php echo esc_attr($span_class);?>">
			<div class="blog-posts-list clearfix<?php echo esc_attr($blog_masonry_class);?>" id="content">
			<?php

			$wp_query = $temp_query;

			?>
			<?php if ( have_posts() ) : ?>

				<?php /* Start the Loop */
				$post_loop_id = 1;
				?>
				<?php while ( have_posts() ) : the_post(); ?>

					<?php
						/* Include the Post-Format-specific template for the content.
						 * If you want to overload this in a child theme then include a file
						 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
						 */

						$post_loop_details['post_loop_id'] = $post_loop_id;
						$post_loop_details['span_class'] = $span_class;

						florian_set_post_details($post_loop_details);

						get_template_part( 'content', get_post_format() );

						$post_loop_id++;
					?>

				<?php endwhile; ?>

			<?php else : ?>

				<?php get_template_part( 'no-results', 'index' ); ?>

			<?php endif; ?>
			</div>
			<?php
			// Post Loops Bottom Banner
			florian_banner_show('posts_loop_bottom');
			?>
			<?php florian_content_nav( 'nav-below' ); ?>

			</div>
			<?php if ( is_active_sidebar( 'main-sidebar' ) && ( $blog_sidebarposition == 'right')) : ?>
			<div class="col-md-3 main-sidebar sidebar">
			<ul id="main-sidebar">
			  <?php dynamic_sidebar( 'main-sidebar' ); ?>
			</ul>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>

	<?php if(is_front_page()): ?>

		<?php florian_blog_editorspick_posts_show(); ?>

	<?php endif; ?>

</div>
<?php get_footer(); ?>
