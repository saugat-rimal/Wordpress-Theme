<?php
/*
 * Template Name: Homepage
 *
 * @package Florian
 */

get_header();

?>

<div class="content-block">

    <?php florian_blog_modern_slider_show(); ?>

    <?php florian_subscribe_block_show(); ?>

    <?php florian_about_block_show(); ?>

    <?php florian_welcome_block_show(); ?>

    <?php florian_featured_categories_block_show(); ?>

    <?php florian_latest_posts_block_show(); ?>

    <?php florian_blog_editorspick_posts_show(); ?>

</div>

<?php get_footer(); ?>
