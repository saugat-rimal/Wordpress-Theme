<?php
/*
*	Related posts
*/
?>
<?php
//for use in the loop, list post titles related to first tag on current post
$tags = wp_get_post_tags(get_the_ID ());
$cats = wp_get_post_categories(get_the_ID ());

$original_post = $post;

$args = '';

$blog_posts_related_by = get_theme_mod('blog_posts_related_by', 'tags');

if(is_single()) {
	$posts_per_page = 4;
} else {
	$posts_per_page = 2;
}

// If by tags
if($blog_posts_related_by == 'tags' && $tags) {

	$intags = array();

	foreach ($tags as $tag) {
		$intags[] = $tag->term_id;
	}

	$args = array(
		'tag__in' => $intags,
		'post__not_in' => array(get_the_ID ()),
		'posts_per_page'=> $posts_per_page
	);
}

// If by categories
if($blog_posts_related_by == 'categories' && $cats) {

	$args = array(
		'category__in' => $cats,
		'post__not_in' => array(get_the_ID ()),
		'posts_per_page'=> $posts_per_page
	);
}

$my_query = new WP_Query($args);

if( $my_query->have_posts() ) {

	echo '<div class="blog-post-related blog-post-related-loop clearfix">';
	echo '<h5>'.esc_html__('You might also like','florian').'</h5>';

	while ($my_query->have_posts()) : $my_query->the_post();
	$post_image_data = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'florian-blog-thumb');

	if(has_post_thumbnail( $post->ID )) {
	    $post_image = 'background-image: url('.$post_image_data[0].');';
	    $post_class = '';
	}
	else {
	    $post_image = '';
	    $post_class = ' blog-post-related-no-image';
	}

	$categories_list = get_the_category_list( ', ', 0, $post->ID );

	?>
	<div class="florian-post blog-post-related-item<?php echo esc_attr($post_class); ?>"<?php florian_add_aos(); ?>>

	<a href="<?php the_permalink() ?>" class="florian-post-image-wrapper">
		<div class="florian-post-image hover-effect-img" data-style="<?php echo esc_attr($post_image);?>"></div>
	</a>

	<div class="blog-post-related-item-inside">

	<?php
	// Post details
    echo '<div class="florian-post-details">

         <div class="florian-post-category">'.wp_kses_post($categories_list).'</div>
         <div class="florian-post-title"><a href="'.esc_url(get_permalink($post->ID)).'"><h5>'.esc_html($post->post_title).'</h5></a></div>';

    echo '<div class="florian-post-info">
         <div class="florian-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div>';

    if(get_theme_mod('blog_posts_author', false) == true) {
        echo '<div class="florian-post-author">'.get_the_author_posts_link().'</div>';
    }

    echo '</div>';
    echo '</div>';
    // END - Post details
	?>
	</div>

	</div>
	<?php
	endwhile;
	echo '<div class="clear"></div>';
	echo '<div class="blog-post-related-separator clearfix"></div>';
	echo '</div>';

}

$post = $original_post;

?>
